# Asli awaazein lagane ka tareeka

1. Folder banao: `app/src/main/res/raw/`
2. Usme file daalo, naam `snd_<naam>.ogg` (ya .wav / .mp3). Naam sirf chhote letters, number, underscore.
3. Jo file nahi hogi uski jagah code wali awaaz chalti rahegi, to ek-ek karke daal sakte ho.
4. File 0.3 se 2 second ki rakho (SoundPool chhoti awaazon ke liye hai). Pehle `call` aur `ouch` wali files daalo.
5. Licence check karo: CC0 / royalty-free chuno (freesound.org me CC0 filter, pixabay.com sound effects, mixkit.co).

## Lion (pehle wale)
snd_ouch, snd_giggle, snd_biggiggle, snd_hello, snd_chirp, snd_sneeze, snd_ear, snd_spin, snd_apple, snd_fish, snd_cookie

## Baaki animals (file ka naam -> kab bajti hai)

### tiger
- snd_tiger  ->  normal awaaz (roar/trumpet/meow...) - sabse zaroori
- snd_tiger_ouch  ->  sir par tap - chhoti 'aow'
- snd_tiger_giggle  ->  pet par tap - khush awaaz
- snd_tiger_biggiggle  ->  pet par 3 tap - lambi khush awaaz
- snd_tiger_squeak  ->  kaan - chhoti squeak
- snd_tiger_sneeze  ->  naak - chheenk
- snd_tiger_hello  ->  paer - chhoti call
- snd_tiger_chirp  ->  poonch - chhoti chirp

### elephant
- snd_elephant  ->  normal awaaz (roar/trumpet/meow...) - sabse zaroori
- snd_elephant_ouch  ->  sir par tap - chhoti 'aow'
- snd_elephant_giggle  ->  pet par tap - khush awaaz
- snd_elephant_biggiggle  ->  pet par 3 tap - lambi khush awaaz
- snd_elephant_squeak  ->  kaan - chhoti squeak
- snd_elephant_sneeze  ->  naak - chheenk
- snd_elephant_hello  ->  paer - chhoti call
- snd_elephant_chirp  ->  poonch - chhoti chirp

### monkey
- snd_monkey  ->  normal awaaz (roar/trumpet/meow...) - sabse zaroori
- snd_monkey_ouch  ->  sir par tap - chhoti 'aow'
- snd_monkey_giggle  ->  pet par tap - khush awaaz
- snd_monkey_biggiggle  ->  pet par 3 tap - lambi khush awaaz
- snd_monkey_squeak  ->  kaan - chhoti squeak
- snd_monkey_sneeze  ->  naak - chheenk
- snd_monkey_hello  ->  paer - chhoti call
- snd_monkey_chirp  ->  poonch - chhoti chirp

### panda
- snd_panda  ->  normal awaaz (roar/trumpet/meow...) - sabse zaroori
- snd_panda_ouch  ->  sir par tap - chhoti 'aow'
- snd_panda_giggle  ->  pet par tap - khush awaaz
- snd_panda_biggiggle  ->  pet par 3 tap - lambi khush awaaz
- snd_panda_squeak  ->  kaan - chhoti squeak
- snd_panda_sneeze  ->  naak - chheenk
- snd_panda_hello  ->  paer - chhoti call
- snd_panda_chirp  ->  poonch - chhoti chirp

### rabbit
- snd_rabbit  ->  normal awaaz (roar/trumpet/meow...) - sabse zaroori
- snd_rabbit_ouch  ->  sir par tap - chhoti 'aow'
- snd_rabbit_giggle  ->  pet par tap - khush awaaz
- snd_rabbit_biggiggle  ->  pet par 3 tap - lambi khush awaaz
- snd_rabbit_squeak  ->  kaan - chhoti squeak
- snd_rabbit_sneeze  ->  naak - chheenk
- snd_rabbit_hello  ->  paer - chhoti call
- snd_rabbit_chirp  ->  poonch - chhoti chirp

### cat
- snd_cat  ->  normal awaaz (roar/trumpet/meow...) - sabse zaroori
- snd_cat_ouch  ->  sir par tap - chhoti 'aow'
- snd_cat_giggle  ->  pet par tap - khush awaaz
- snd_cat_biggiggle  ->  pet par 3 tap - lambi khush awaaz
- snd_cat_squeak  ->  kaan - chhoti squeak
- snd_cat_sneeze  ->  naak - chheenk
- snd_cat_hello  ->  paer - chhoti call
- snd_cat_chirp  ->  poonch - chhoti chirp

### dog
- snd_dog  ->  normal awaaz (roar/trumpet/meow...) - sabse zaroori
- snd_dog_ouch  ->  sir par tap - chhoti 'aow'
- snd_dog_giggle  ->  pet par tap - khush awaaz
- snd_dog_biggiggle  ->  pet par 3 tap - lambi khush awaaz
- snd_dog_squeak  ->  kaan - chhoti squeak
- snd_dog_sneeze  ->  naak - chheenk
- snd_dog_hello  ->  paer - chhoti call
- snd_dog_chirp  ->  poonch - chhoti chirp

### fox
- snd_fox  ->  normal awaaz (roar/trumpet/meow...) - sabse zaroori
- snd_fox_ouch  ->  sir par tap - chhoti 'aow'
- snd_fox_giggle  ->  pet par tap - khush awaaz
- snd_fox_biggiggle  ->  pet par 3 tap - lambi khush awaaz
- snd_fox_squeak  ->  kaan - chhoti squeak
- snd_fox_sneeze  ->  naak - chheenk
- snd_fox_hello  ->  paer - chhoti call
- snd_fox_chirp  ->  poonch - chhoti chirp

### bear
- snd_bear  ->  normal awaaz (roar/trumpet/meow...) - sabse zaroori
- snd_bear_ouch  ->  sir par tap - chhoti 'aow'
- snd_bear_giggle  ->  pet par tap - khush awaaz
- snd_bear_biggiggle  ->  pet par 3 tap - lambi khush awaaz
- snd_bear_squeak  ->  kaan - chhoti squeak
- snd_bear_sneeze  ->  naak - chheenk
- snd_bear_hello  ->  paer - chhoti call
- snd_bear_chirp  ->  poonch - chhoti chirp

### parrot
- snd_parrot  ->  normal awaaz (roar/trumpet/meow...) - sabse zaroori
- snd_parrot_ouch  ->  sir par tap - chhoti 'aow'
- snd_parrot_giggle  ->  pet par tap - khush awaaz
- snd_parrot_biggiggle  ->  pet par 3 tap - lambi khush awaaz
- snd_parrot_squeak  ->  kaan - chhoti squeak
- snd_parrot_sneeze  ->  naak - chheenk
- snd_parrot_hello  ->  paer - chhoti call
- snd_parrot_chirp  ->  poonch - chhoti chirp

### pig
- snd_pig  ->  normal awaaz (roar/trumpet/meow...) - sabse zaroori
- snd_pig_ouch  ->  sir par tap - chhoti 'aow'
- snd_pig_giggle  ->  pet par tap - khush awaaz
- snd_pig_biggiggle  ->  pet par 3 tap - lambi khush awaaz
- snd_pig_squeak  ->  kaan - chhoti squeak
- snd_pig_sneeze  ->  naak - chheenk
- snd_pig_hello  ->  paer - chhoti call
- snd_pig_chirp  ->  poonch - chhoti chirp

### frog
- snd_frog  ->  normal awaaz (roar/trumpet/meow...) - sabse zaroori
- snd_frog_ouch  ->  sir par tap - chhoti 'aow'
- snd_frog_giggle  ->  pet par tap - khush awaaz
- snd_frog_biggiggle  ->  pet par 3 tap - lambi khush awaaz
- snd_frog_squeak  ->  kaan - chhoti squeak
- snd_frog_sneeze  ->  naak - chheenk
- snd_frog_hello  ->  paer - chhoti call
- snd_frog_chirp  ->  poonch - chhoti chirp

### penguin
- snd_penguin  ->  normal awaaz (roar/trumpet/meow...) - sabse zaroori
- snd_penguin_ouch  ->  sir par tap - chhoti 'aow'
- snd_penguin_giggle  ->  pet par tap - khush awaaz
- snd_penguin_biggiggle  ->  pet par 3 tap - lambi khush awaaz
- snd_penguin_squeak  ->  kaan - chhoti squeak
- snd_penguin_sneeze  ->  naak - chheenk
- snd_penguin_hello  ->  paer - chhoti call
- snd_penguin_chirp  ->  poonch - chhoti chirp

### koala
- snd_koala  ->  normal awaaz (roar/trumpet/meow...) - sabse zaroori
- snd_koala_ouch  ->  sir par tap - chhoti 'aow'
- snd_koala_giggle  ->  pet par tap - khush awaaz
- snd_koala_biggiggle  ->  pet par 3 tap - lambi khush awaaz
- snd_koala_squeak  ->  kaan - chhoti squeak
- snd_koala_sneeze  ->  naak - chheenk
- snd_koala_hello  ->  paer - chhoti call
- snd_koala_chirp  ->  poonch - chhoti chirp

### cow
- snd_cow  ->  normal awaaz (roar/trumpet/meow...) - sabse zaroori
- snd_cow_ouch  ->  sir par tap - chhoti 'aow'
- snd_cow_giggle  ->  pet par tap - khush awaaz
- snd_cow_biggiggle  ->  pet par 3 tap - lambi khush awaaz
- snd_cow_squeak  ->  kaan - chhoti squeak
- snd_cow_sneeze  ->  naak - chheenk
- snd_cow_hello  ->  paer - chhoti call
- snd_cow_chirp  ->  poonch - chhoti chirp
