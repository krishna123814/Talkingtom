package com.example.liontalk

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

enum class Animal(
    val displayName: String,
    val hindiName: String,
    val abilityHint: String,
    val soundKey: String,
    val fur: Int,
    val lightFur: Int,
    val darkFur: Int
) {
    LION("Lion", "Sher", "Tap tummy · giggle", "hello", Color.parseColor("#C9954F"), Color.parseColor("#F0DDB8"), Color.parseColor("#5E3517")),
    TIGER("Tiger", "Baagh", "Tap paw · friendly roar", "tiger", Color.parseColor("#E98A31"), Color.parseColor("#FFD276"), Color.parseColor("#34231D")),
    ELEPHANT("Elephant", "Haathi", "Tap trunk · bubble spray", "elephant", Color.parseColor("#8998A8"), Color.parseColor("#D9E0E5"), Color.parseColor("#465462")),
    MONKEY("Monkey", "Bandar", "Tap tummy · banana toss", "monkey", Color.parseColor("#A96A43"), Color.parseColor("#F3D8A8"), Color.parseColor("#563721")),
    PANDA("Panda", "Panda", "Tap tummy · gentle roll", "panda", Color.parseColor("#F3F1E9"), Color.parseColor("#FFFFFF"), Color.parseColor("#272B32")),
    RABBIT("Rabbit", "Khargosh", "Tap ears · super hop", "rabbit", Color.parseColor("#E9DCE5"), Color.parseColor("#FFF7F2"), Color.parseColor("#A77B91")),
    CAT("Cat", "Billi", "Tap tail · purr bubbles", "cat", Color.parseColor("#9DA8B5"), Color.parseColor("#F1E6D6"), Color.parseColor("#53616F")),
    DOG("Dog", "Kutta", "Tap paw · high-five", "dog", Color.parseColor("#B8794D"), Color.parseColor("#F4D6A8"), Color.parseColor("#593923")),
    FOX("Fox", "Lomdi", "Tap tail · quick dash", "fox", Color.parseColor("#E97835"), Color.parseColor("#FFF0D5"), Color.parseColor("#863C26")),
    BEAR("Bear", "Bhalu", "Tap tummy · bear hug", "bear", Color.parseColor("#8B5C43"), Color.parseColor("#D9B28A"), Color.parseColor("#493126")),
    PARROT("Parrot", "Tota", "Tap wing · flap & squawk", "parrot", Color.parseColor("#48A968"), Color.parseColor("#A6D66B"), Color.parseColor("#226643")),
    PIG("Pig", "Suar", "Tap snout · happy oink", "pig", Color.parseColor("#F4A9B8"), Color.parseColor("#FAD0D8"), Color.parseColor("#B55A70")),
    FROG("Frog", "Medhak", "Tap mouth · tongue flick", "frog", Color.parseColor("#6CBF4B"), Color.parseColor("#DDF2A8"), Color.parseColor("#2F6B2E")),
    PENGUIN("Penguin", "Penguin", "Tap flipper · happy flap", "penguin", Color.parseColor("#2E3B4E"), Color.parseColor("#FFFFFF"), Color.parseColor("#161D28")),
    KOALA("Koala", "Koala", "Tap tummy · leaf munch", "koala", Color.parseColor("#9EA3AA"), Color.parseColor("#E6E8EA"), Color.parseColor("#565C64")),
    COW("Cow", "Gaay", "Tap bell · moo moo", "cow", Color.parseColor("#F6F3EC"), Color.parseColor("#F4C3CC"), Color.parseColor("#2E2A2A"));

    val pickerName: String get() = "$displayName · $hindiName"
}

/**
 * Simple, expressive vector companions for the ten animals alongside Lion.
 * Kept independent from the original, highly detailed lion illustration.
 */
class AnimalArt {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 7f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val detail = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val rect = RectF()
    private val path = Path()
    private val eyeWhite = Color.parseColor("#FFFDF7")
    private val pupil = Color.parseColor("#201A1A")
    private val blush = Color.parseColor("#E98B8B")

    fun draw(
        c: Canvas,
        animal: Animal,
        time: Float,
        special: Boolean,
        progress: Float,
        feeding: Boolean = false
    ) {
        val p = progress.coerceIn(0f, 1f)
        val hop = if (special && animal == Animal.RABBIT) -70f * sin(PI.toFloat() * p) else 0f
        val wiggle = if (special) sin(time * 32f) * 5f * (1f - p * 0.25f) else 0f

        c.save()
        if (special && animal == Animal.PANDA) {
            c.rotate(360f * smooth(p), 500f, 840f)
        } else if (special && animal == Animal.FOX) {
            c.translate(45f * sin(PI.toFloat() * p), 0f)
        }
        c.translate(0f, hop)

        drawTail(c, animal, time, special, p)
        drawLegs(c, animal)
        drawBody(c, animal)
        drawEars(c, animal, wiggle)
        drawHead(c, animal, time, special, wiggle)
        drawFace(c, animal, time, special || feeding)
        if (special) drawAbility(c, animal, time, p)
        c.restore()
    }

    private fun smooth(x: Float): Float {
        val v = x.coerceIn(0f, 1f)
        return v * v * (3f - 2f * v)
    }

    private fun oval(c: Canvas, cx: Float, cy: Float, rx: Float, ry: Float, color: Int, edge: Int? = null) {
        rect.set(cx - rx, cy - ry, cx + rx, cy + ry)
        fill.color = color
        c.drawOval(rect, fill)
        outline.color = edge ?: Color.argb(120, 45, 30, 27)
        outline.strokeWidth = 7f
        c.drawOval(rect, outline)
    }

    private fun circle(c: Canvas, cx: Float, cy: Float, r: Float, color: Int) {
        fill.color = color
        c.drawCircle(cx, cy, r, fill)
    }

    private fun stroke(c: Canvas, points: FloatArray, color: Int, width: Float) {
        path.reset()
        path.moveTo(points[0], points[1])
        var i = 2
        while (i < points.size) {
            path.quadTo(points[i], points[i + 1], points[i + 2], points[i + 3])
            i += 4
        }
        detail.color = color
        detail.strokeWidth = width
        c.drawPath(path, detail)
    }

    private fun triangle(c: Canvas, points: FloatArray, color: Int) {
        path.reset()
        path.moveTo(points[0], points[1])
        path.lineTo(points[2], points[3])
        path.lineTo(points[4], points[5])
        path.close()
        fill.color = color
        c.drawPath(path, fill)
        outline.color = Color.argb(120, 45, 30, 27)
        outline.strokeWidth = 6f
        c.drawPath(path, outline)
    }

    private fun drawTail(c: Canvas, animal: Animal, time: Float, special: Boolean, p: Float) {
        val wag = sin(time * 5f) * 18f + if (special) sin(p * PI.toFloat() * 5f) * 38f else 0f
        path.reset()
        when (animal) {
            Animal.CAT -> {
                path.moveTo(665f, 1015f)
                path.cubicTo(835f, 1080f, 850f, 850f + wag, 785f, 745f + wag)
            }
            Animal.DOG -> {
                path.moveTo(675f, 920f)
                path.cubicTo(820f, 935f + wag, 820f, 820f + wag, 790f, 785f + wag)
            }
            Animal.FOX, Animal.TIGER -> {
                path.moveTo(675f, 1010f)
                path.cubicTo(840f, 1080f, 900f, 830f + wag, 820f, 740f + wag)
            }
            Animal.MONKEY -> {
                path.moveTo(660f, 990f)
                path.cubicTo(860f, 1090f, 910f, 780f + wag, 780f, 820f + wag)
                path.cubicTo(700f, 850f + wag, 825f, 930f + wag, 850f, 825f + wag)
            }
            Animal.BEAR, Animal.PANDA -> {
                path.moveTo(665f, 990f)
                path.cubicTo(760f, 1005f + wag, 780f, 920f + wag, 735f, 900f + wag)
            }
            Animal.PIG -> {
                path.moveTo(665f, 985f)
                path.cubicTo(745f, 1010f, 770f, 925f, 718f, 930f)
                path.cubicTo(680f, 935f, 700f, 985f, 738f, 968f)
            }
            Animal.COW -> {
                path.moveTo(665f, 985f)
                path.cubicTo(800f, 960f + wag, 800f, 890f + wag, 775f, 835f + wag)
            }
            Animal.PARROT -> {
                path.moveTo(555f, 920f)
                path.cubicTo(620f, 1050f, 650f, 1120f, 700f, 1190f)
                c.save()
                c.rotate(if (special) sin(p * PI.toFloat() * 4f) * 18f else 0f, 630f, 1050f)
                detail.color = animal.darkFur
                detail.strokeWidth = 18f
                c.drawPath(path, detail)
                detail.color = Color.parseColor("#F0C84A")
                detail.strokeWidth = 10f
                c.drawLine(650f, 1090f, 690f, 1170f, detail)
                c.restore()
                return
            }
            else -> return
        }
        detail.color = animal.darkFur
        detail.strokeWidth = when (animal) {
            Animal.FOX -> 82f
            Animal.TIGER -> 32f
            Animal.MONKEY -> 22f
            Animal.PIG -> 20f
            Animal.COW -> 18f
            else -> 30f
        }
        c.drawPath(path, detail)
        detail.color = animal.fur
        detail.strokeWidth = when (animal) {
            Animal.FOX -> 66f
            Animal.TIGER -> 23f
            Animal.MONKEY -> 14f
            Animal.PIG -> 12f
            Animal.COW -> 10f
            else -> 21f
        }
        c.drawPath(path, detail)
        if (animal == Animal.COW) oval(c, 775f, 825f + wag, 20f, 32f, animal.darkFur, null)
        if (animal == Animal.FOX) {
            detail.color = Color.WHITE
            detail.strokeWidth = 54f
            path.reset()
            path.moveTo(810f, 758f + wag)
            path.quadTo(850f, 716f + wag, 820f, 740f + wag)
            c.drawPath(path, detail)
        }
        if (animal == Animal.TIGER) {
            detail.color = animal.darkFur
            detail.strokeWidth = 6f
            for (i in 0..3) c.drawLine(760f + i * 22f, 820f + wag, 780f + i * 17f, 838f + wag, detail)
        }
    }

    private fun drawLegs(c: Canvas, animal: Animal) {
        val legColor = when (animal) {
            Animal.PANDA -> Color.WHITE
            Animal.PARROT -> animal.fur
            else -> animal.fur
        }
        val foot = when (animal) {
            Animal.PENGUIN -> Color.parseColor("#F2A33A")
            Animal.COW -> Color.parseColor("#6B5A57")
            else -> animal.lightFur
        }
        for (x in intArrayOf(365, 635)) {
            oval(c, x.toFloat(), 1095f, 72f, 145f, legColor, animal.darkFur)
            oval(c, x.toFloat(), 1200f, 78f, 54f, foot, animal.darkFur)
        }
        if (animal == Animal.PARROT) {
            detail.color = Color.parseColor("#E9A83E")
            detail.strokeWidth = 15f
            c.drawLine(454f, 1000f, 445f, 1090f, detail)
            c.drawLine(546f, 1000f, 555f, 1090f, detail)
        }
    }

    private fun drawBody(c: Canvas, animal: Animal) {
        val centerY = if (animal == Animal.PARROT) 870f else 900f
        val rx = if (animal == Animal.PARROT) 215f else 255f
        val ry = if (animal == Animal.PARROT) 300f else 330f
        oval(c, 500f, centerY, rx, ry, animal.fur, animal.darkFur)
        oval(c, 500f, centerY + 80f, rx * 0.62f, ry * 0.62f, animal.lightFur, null)

        when (animal) {
            Animal.TIGER -> {
                detail.color = animal.darkFur
                detail.strokeWidth = 22f
                for (i in -2..2) {
                    val x = 500f + i * 72f
                    c.drawLine(x - 28f, 680f, x, 735f, detail)
                    c.drawLine(x + 15f, 1030f, x + 45f, 1075f, detail)
                }
            }
            Animal.PANDA -> {
                oval(c, 385f, 875f, 58f, 95f, animal.darkFur, null)
                oval(c, 615f, 875f, 58f, 95f, animal.darkFur, null)
            }
            Animal.MONKEY -> {
                circle(c, 405f, 760f, 32f, Color.parseColor("#E9B467"))
                circle(c, 595f, 760f, 32f, Color.parseColor("#E9B467"))
            }
            Animal.PARROT -> {
                c.save()
                c.rotate(-17f, 340f, 830f)
                oval(c, 340f, 830f, 82f, 190f, Color.parseColor("#23884E"), Color.parseColor("#175A39"))
                c.restore()
                c.save()
                c.rotate(17f, 660f, 830f)
                oval(c, 660f, 830f, 82f, 190f, Color.parseColor("#23884E"), Color.parseColor("#175A39"))
                c.restore()
                for (i in 0..2) {
                    detail.color = intArrayOf(Color.parseColor("#E9C84A"), Color.parseColor("#3976B9"), Color.parseColor("#E75F48"))[i]
                    detail.strokeWidth = 18f
                    c.drawLine(465f + i * 35f, 1080f, 450f + i * 55f, 1215f, detail)
                }
            }
            Animal.PENGUIN -> {
                c.save()
                c.rotate(10f, 300f, 700f)
                oval(c, 285f, 850f, 52f, 175f, animal.fur, animal.darkFur)
                c.restore()
                c.save()
                c.rotate(-10f, 700f, 700f)
                oval(c, 715f, 850f, 52f, 175f, animal.fur, animal.darkFur)
                c.restore()
            }
            Animal.COW -> {
                oval(c, 395f, 830f, 72f, 56f, animal.darkFur, null)
                oval(c, 615f, 960f, 82f, 62f, animal.darkFur, null)
                oval(c, 415f, 1030f, 52f, 40f, animal.darkFur, null)
                stroke(c, floatArrayOf(385f, 735f, 500f, 790f, 615f, 735f), Color.parseColor("#D8483F"), 20f)
                oval(c, 500f, 788f, 32f, 32f, Color.parseColor("#F2C94C"), Color.parseColor("#A8791F"))
                circle(c, 500f, 815f, 6f, Color.parseColor("#7A5A1C"))
            }
            else -> Unit
        }
    }

    private fun drawEars(c: Canvas, animal: Animal, wiggle: Float) {
        when (animal) {
            Animal.RABBIT -> {
                c.save()
                c.rotate(-8f + wiggle, 420f, 340f)
                oval(c, 420f, 290f, 66f, 190f, animal.fur, animal.darkFur)
                oval(c, 420f, 290f, 30f, 145f, Color.parseColor("#E8A7B5"), null)
                c.restore()
                c.save()
                c.rotate(8f - wiggle, 580f, 340f)
                oval(c, 580f, 290f, 66f, 190f, animal.fur, animal.darkFur)
                oval(c, 580f, 290f, 30f, 145f, Color.parseColor("#E8A7B5"), null)
                c.restore()
            }
            Animal.ELEPHANT -> {
                oval(c, 290f, 475f, 118f, 170f, animal.fur, animal.darkFur)
                oval(c, 710f, 475f, 118f, 170f, animal.fur, animal.darkFur)
                oval(c, 290f, 475f, 74f, 128f, Color.parseColor("#DDAEB4"), null)
                oval(c, 710f, 475f, 74f, 128f, Color.parseColor("#DDAEB4"), null)
            }
            Animal.DOG -> {
                c.save()
                c.rotate(-18f + wiggle, 330f, 425f)
                oval(c, 330f, 450f, 82f, 155f, animal.darkFur, animal.darkFur)
                oval(c, 330f, 450f, 62f, 132f, animal.fur, null)
                c.restore()
                c.save()
                c.rotate(18f - wiggle, 670f, 425f)
                oval(c, 670f, 450f, 82f, 155f, animal.darkFur, animal.darkFur)
                oval(c, 670f, 450f, 62f, 132f, animal.fur, null)
                c.restore()
            }
            Animal.CAT, Animal.FOX, Animal.TIGER, Animal.PARROT -> {
                val earColor = if (animal == Animal.PARROT) animal.lightFur else animal.fur
                triangle(c, floatArrayOf(330f, 460f, 355f, 230f, 475f, 390f), earColor)
                triangle(c, floatArrayOf(670f, 460f, 645f, 230f, 525f, 390f), earColor)
                if (animal == Animal.CAT || animal == Animal.FOX) {
                    triangle(c, floatArrayOf(357f, 390f, 363f, 285f, 433f, 375f), Color.parseColor("#E6A2A5"))
                    triangle(c, floatArrayOf(643f, 390f, 637f, 285f, 567f, 375f), Color.parseColor("#E6A2A5"))
                }
            }
            Animal.PANDA, Animal.BEAR, Animal.MONKEY -> {
                circle(c, 350f, 365f, 83f, animal.darkFur)
                circle(c, 650f, 365f, 83f, animal.darkFur)
                val inner = if (animal == Animal.BEAR) animal.fur else Color.parseColor("#E5B0A3")
                circle(c, 350f, 365f, 45f, inner)
                circle(c, 650f, 365f, 45f, inner)
            }
            Animal.PIG -> {
                triangle(c, floatArrayOf(335f, 445f, 300f, 280f, 450f, 345f), animal.fur)
                triangle(c, floatArrayOf(345f, 400f, 328f, 318f, 410f, 352f), animal.lightFur)
                triangle(c, floatArrayOf(665f, 445f, 700f, 280f, 550f, 345f), animal.fur)
                triangle(c, floatArrayOf(655f, 400f, 672f, 318f, 590f, 352f), animal.lightFur)
            }
            Animal.KOALA -> {
                oval(c, 330f, 360f, 105f, 105f, animal.fur, animal.darkFur)
                oval(c, 670f, 360f, 105f, 105f, animal.fur, animal.darkFur)
                oval(c, 330f, 360f, 62f, 62f, animal.lightFur, null)
                oval(c, 670f, 360f, 62f, 62f, animal.lightFur, null)
            }
            Animal.COW -> {
                val horn = Color.parseColor("#E8D8A0")
                triangle(c, floatArrayOf(385f, 295f, 360f, 190f, 440f, 258f), horn)
                triangle(c, floatArrayOf(615f, 295f, 640f, 190f, 560f, 258f), horn)
                c.save()
                c.rotate(-20f + wiggle, 310f, 430f)
                oval(c, 300f, 430f, 95f, 52f, animal.fur, animal.darkFur)
                oval(c, 300f, 432f, 62f, 30f, animal.lightFur, null)
                c.restore()
                c.save()
                c.rotate(20f - wiggle, 690f, 430f)
                oval(c, 700f, 430f, 95f, 52f, animal.fur, animal.darkFur)
                oval(c, 700f, 432f, 62f, 30f, animal.lightFur, null)
                c.restore()
            }
            Animal.FROG, Animal.PENGUIN, Animal.LION -> Unit
        }
    }

    private fun drawHead(c: Canvas, animal: Animal, time: Float, special: Boolean, wiggle: Float) {
        val tilt = if (special) sin(time * 29f) * 3f + wiggle else sin(time * 1.2f) * 1.5f
        c.save()
        c.rotate(tilt, 500f, 520f)
        val rx = when (animal) {
            Animal.ELEPHANT -> 245f
            Animal.FOX -> 225f
            Animal.PARROT -> 195f
            Animal.FROG -> 250f
            Animal.PIG -> 235f
            Animal.PENGUIN -> 215f
            Animal.KOALA -> 235f
            else -> 220f
        }
        val ry = when (animal) {
            Animal.PARROT -> 220f
            Animal.FROG -> 185f
            Animal.PENGUIN, Animal.PIG -> 220f
            Animal.TIGER, Animal.CAT, Animal.RABBIT -> 210f
            else -> 235f
        }
        oval(c, 500f, 475f, rx, ry, animal.fur, animal.darkFur)

        when (animal) {
            Animal.PANDA -> {
                oval(c, 420f, 450f, 64f, 82f, animal.darkFur, null)
                oval(c, 580f, 450f, 64f, 82f, animal.darkFur, null)
            }
            Animal.MONKEY -> {
                oval(c, 500f, 535f, 150f, 112f, animal.lightFur, null)
                oval(c, 355f, 465f, 54f, 72f, Color.parseColor("#E9B467"), null)
                oval(c, 645f, 465f, 54f, 72f, Color.parseColor("#E9B467"), null)
            }
            Animal.FOX -> {
                triangle(c, floatArrayOf(500f, 660f, 365f, 560f, 410f, 440f), animal.lightFur)
                triangle(c, floatArrayOf(500f, 660f, 635f, 560f, 590f, 440f), animal.lightFur)
            }
            Animal.DOG -> {
                oval(c, 500f, 570f, 145f, 96f, animal.lightFur, null)
                oval(c, 425f, 405f, 54f, 74f, Color.parseColor("#3D2B25"), null)
                oval(c, 575f, 405f, 54f, 74f, Color.parseColor("#3D2B25"), null)
            }
            Animal.RABBIT -> {
                oval(c, 500f, 555f, 132f, 98f, animal.lightFur, null)
                oval(c, 458f, 588f, 56f, 42f, Color.WHITE, null)
                oval(c, 542f, 588f, 56f, 42f, Color.WHITE, null)
            }
            Animal.CAT -> {
                oval(c, 500f, 555f, 148f, 95f, animal.lightFur, null)
                oval(c, 455f, 520f, 22f, 15f, Color.parseColor("#EBC1A5"), null)
                oval(c, 545f, 520f, 22f, 15f, Color.parseColor("#EBC1A5"), null)
            }
            Animal.BEAR -> oval(c, 500f, 570f, 132f, 96f, animal.lightFur, null)
            Animal.TIGER -> {
                oval(c, 500f, 565f, 150f, 105f, animal.lightFur, null)
                detail.color = animal.darkFur
                detail.strokeWidth = 13f
                for (i in -1..1) {
                    val x = 500f + i * 95f
                    c.drawLine(x - 20f, 300f, x, 360f, detail)
                }
            }
            Animal.PARROT -> {
                oval(c, 500f, 570f, 126f, 102f, Color.parseColor("#E8D75A"), null)
                triangle(c, floatArrayOf(545f, 480f, 735f, 530f, 565f, 600f), Color.parseColor("#ECA33E"))
                triangle(c, floatArrayOf(565f, 600f, 735f, 530f, 625f, 650f), Color.parseColor("#D96A35"))
            }
            Animal.ELEPHANT -> {
                oval(c, 500f, 535f, 102f, 130f, Color.parseColor("#98A6B3"), null)
                path.reset()
                path.moveTo(500f, 485f)
                path.cubicTo(445f, 610f, 445f, 735f, 510f, 750f)
                path.cubicTo(575f, 760f, 565f, 680f, 545f, 640f)
                detail.color = animal.darkFur
                detail.strokeWidth = 75f
                c.drawPath(path, detail)
                detail.color = animal.fur
                detail.strokeWidth = 58f
                c.drawPath(path, detail)
                circle(c, 515f, 743f, 8f, animal.darkFur)
            }
            Animal.PIG -> {
                oval(c, 500f, 585f, 104f, 78f, Color.parseColor("#F7BCC8"), animal.darkFur)
                oval(c, 466f, 585f, 15f, 25f, animal.darkFur, null)
                oval(c, 534f, 585f, 15f, 25f, animal.darkFur, null)
            }
            Animal.FROG -> {
                oval(c, 500f, 590f, 175f, 100f, animal.lightFur, null)
                oval(c, 425f, 300f, 76f, 76f, animal.fur, animal.darkFur)
                oval(c, 575f, 300f, 76f, 76f, animal.fur, animal.darkFur)
                circle(c, 478f, 475f, 6f, animal.darkFur)
                circle(c, 522f, 475f, 6f, animal.darkFur)
            }
            Animal.PENGUIN -> oval(c, 500f, 525f, 165f, 140f, animal.lightFur, null)
            Animal.KOALA -> {
                oval(c, 500f, 565f, 135f, 100f, animal.lightFur, null)
                oval(c, 500f, 520f, 56f, 76f, Color.parseColor("#3B3B42"), null)
                circle(c, 484f, 494f, 10f, Color.parseColor("#8A8A92"))
            }
            Animal.COW -> {
                oval(c, 592f, 405f, 76f, 92f, animal.darkFur, null)
                oval(c, 500f, 590f, 150f, 100f, animal.lightFur, null)
                oval(c, 447f, 590f, 17f, 25f, Color.parseColor("#B77A86"), null)
                oval(c, 553f, 590f, 17f, 25f, Color.parseColor("#B77A86"), null)
            }
            else -> Unit
        }
        if (animal == Animal.TIGER) {
            detail.color = animal.darkFur
            detail.strokeWidth = 10f
            c.drawLine(365f, 480f, 405f, 505f, detail)
            c.drawLine(635f, 480f, 595f, 505f, detail)
        }
        if (animal == Animal.FOX) {
            oval(c, 500f, 610f, 62f, 42f, Color.parseColor("#272425"), null)
        }
        c.restore()
    }

    private fun drawFace(c: Canvas, animal: Animal, time: Float, special: Boolean) {
        val eyeY = when (animal) {
            Animal.PARROT -> 430f
            Animal.FROG -> 300f
            else -> 435f
        }
        val blink = abs(sin(time * 0.9f + animal.ordinal * 0.74f)) > 0.985f
        for (x in intArrayOf(425, 575)) {
            val cx = x.toFloat()
            if (animal == Animal.PANDA) {
                c.save()
                c.rotate(if (cx < 500f) -18f else 18f, cx, eyeY)
                oval(c, cx, eyeY, 46f, 62f, animal.darkFur, null)
                c.restore()
            }
            if (blink) {
                detail.color = animal.darkFur
                detail.strokeWidth = 12f
                c.drawLine(cx - 27f, eyeY, cx + 27f, eyeY, detail)
            } else {
                oval(c, cx, eyeY, 34f, 43f, eyeWhite, null)
                circle(c, cx + 3f, eyeY + 3f, 21f, pupil)
                circle(c, cx - 4f, eyeY - 6f, 7f, Color.WHITE)
            }
        }
        when (animal) {
            Animal.CAT, Animal.RABBIT, Animal.DOG, Animal.BEAR, Animal.MONKEY -> {
                oval(c, 500f, 520f, 80f, 50f, animal.lightFur, null)
            }
            Animal.PANDA -> oval(c, 500f, 530f, 76f, 48f, Color.WHITE, null)
            else -> Unit
        }
        val noseColor = when (animal) {
            Animal.PARROT -> Color.parseColor("#2D5941")
            Animal.TIGER -> animal.darkFur
            Animal.ELEPHANT -> animal.darkFur
            Animal.FOX -> Color.parseColor("#2B2020")
            else -> Color.parseColor("#7F4545")
        }
        val noNose = animal == Animal.PARROT || animal == Animal.ELEPHANT || animal.ordinal >= Animal.PIG.ordinal
        if (!noNose) {
            triangle(c, floatArrayOf(480f, 510f, 520f, 510f, 500f, 535f), noseColor)
            if (animal == Animal.MONKEY || animal == Animal.BEAR || animal == Animal.CAT || animal == Animal.DOG || animal == Animal.RABBIT || animal == Animal.PANDA) {
                path.reset()
                path.moveTo(500f, 532f)
                path.lineTo(500f, 550f)
                path.moveTo(500f, 550f)
                path.quadTo(477f, 570f, 455f, 548f)
                path.moveTo(500f, 550f)
                path.quadTo(523f, 570f, 545f, 548f)
                detail.color = animal.darkFur
                detail.strokeWidth = 7f
                c.drawPath(path, detail)
            }
        }
        if (special && !noNose) {
            oval(c, 500f, 578f, 48f, 37f, Color.parseColor("#5C2732"), null)
            oval(c, 500f, 603f, 23f, 12f, Color.parseColor("#E88E9B"), null)
        }
        if (animal == Animal.RABBIT || animal == Animal.CAT) {
            circle(c, 390f, 560f, 18f, Color.argb(130, Color.red(blush), Color.green(blush), Color.blue(blush)))
            circle(c, 610f, 560f, 18f, Color.argb(130, Color.red(blush), Color.green(blush), Color.blue(blush)))
            detail.color = animal.darkFur
            detail.strokeWidth = 4f
            for (side in intArrayOf(-1, 1)) {
                for (i in 0..1) {
                    c.drawLine(420f + side * 40f, 535f + i * 17f, 420f + side * 112f, 518f + i * 28f, detail)
                }
            }
        }
        if (animal.ordinal >= Animal.PIG.ordinal) drawNewFace(c, animal, special)
        if (animal == Animal.DOG) {
            circle(c, 370f, 380f, 24f, Color.parseColor("#5B3A27"))
            circle(c, 630f, 380f, 24f, Color.parseColor("#5B3A27"))
        }
    }

    private fun drawNewFace(c: Canvas, animal: Animal, special: Boolean) {
        val mouth = Color.parseColor("#5C2732")
        val tongue = Color.parseColor("#E88E9B")
        when (animal) {
            Animal.PIG -> {
                if (special) {
                    oval(c, 500f, 695f, 42f, 28f, mouth, null)
                    oval(c, 500f, 710f, 22f, 10f, tongue, null)
                } else {
                    stroke(c, floatArrayOf(450f, 672f, 500f, 705f, 550f, 672f), animal.darkFur, 7f)
                }
            }
            Animal.FROG -> {
                if (special) {
                    oval(c, 500f, 595f, 120f, 55f, mouth, null)
                    oval(c, 500f, 620f, 60f, 18f, tongue, null)
                } else {
                    stroke(c, floatArrayOf(350f, 565f, 500f, 650f, 650f, 565f), animal.darkFur, 8f)
                }
            }
            Animal.PENGUIN -> {
                val beakLow = if (special) 18f else 0f
                triangle(c, floatArrayOf(473f, 548f, 527f, 548f, 500f, 580f + beakLow), Color.parseColor("#D9822B"))
                triangle(c, floatArrayOf(458f, 512f, 542f, 512f, 500f, 566f), Color.parseColor("#F2A33A"))
                val pink = Color.argb(130, Color.red(blush), Color.green(blush), Color.blue(blush))
                circle(c, 380f, 560f, 20f, pink)
                circle(c, 620f, 560f, 20f, pink)
            }
            Animal.KOALA -> {
                if (special) {
                    oval(c, 500f, 645f, 40f, 26f, mouth, null)
                } else {
                    stroke(c, floatArrayOf(452f, 625f, 500f, 656f, 548f, 625f), animal.darkFur, 7f)
                }
            }
            Animal.COW -> {
                if (special) {
                    oval(c, 500f, 655f, 38f, 24f, mouth, null)
                } else {
                    stroke(c, floatArrayOf(450f, 640f, 500f, 672f, 550f, 640f), animal.darkFur, 7f)
                }
            }
            else -> Unit
        }
    }

    private fun drawAbility(c: Canvas, animal: Animal, time: Float, p: Float) {
        when (animal) {
            Animal.ELEPHANT -> {
                for (i in 0..3) {
                    val phase = p * 6f + i * 1.65f
                    val bx = 510f + sin(phase) * (48f + i * 7f)
                    val by = 765f - (phase % 4f) * 30f
                    circle(c, bx, by, 10f + (i % 2) * 4f, Color.parseColor("#83D8F3"))
                }
            }
            Animal.MONKEY -> {
                val rise = sin(PI.toFloat() * p) * 150f
                c.save()
                c.rotate(-25f + p * 50f, 715f, 575f - rise)
                oval(c, 715f, 575f - rise, 20f, 52f, Color.parseColor("#F4C544"), Color.parseColor("#B77C2E"))
                detail.color = Color.parseColor("#59833A")
                detail.strokeWidth = 9f
                c.drawLine(710f, 526f - rise, 732f, 520f - rise, detail)
                c.restore()
            }
            Animal.CAT -> {
                for (i in 0..2) {
                    val r = 28f + ((time * 42f + i * 35f) % 90f)
                    outline.color = Color.parseColor("#E8C9F4")
                    outline.strokeWidth = 8f
                    outline.alpha = (170 - r).coerceIn(30f, 170f).toInt()
                    rect.set(500f - r, 395f - r, 500f + r, 395f + r)
                    c.drawOval(rect, outline)
                }
                outline.alpha = 255
            }
            Animal.DOG -> {
                c.save()
                c.rotate(-52f * sin(p * PI.toFloat()), 420f, 890f)
                oval(c, 420f, 890f, 65f, 90f, animal.fur, animal.darkFur)
                c.restore()
                circle(c, 350f, 785f, 20f, Color.parseColor("#F5E0A8"))
                circle(c, 650f, 785f, 20f, Color.parseColor("#F5E0A8"))
            }
            Animal.FOX -> {
                detail.color = Color.WHITE
                detail.strokeWidth = 11f
                for (i in 0..2) {
                    val x = 230f + i * 55f + p * 130f
                    c.drawLine(x, 870f + i * 32f, x + 50f, 870f + i * 32f, detail)
                }
            }
            Animal.BEAR -> {
                c.save()
                c.rotate(35f * sin(p * PI.toFloat()), 360f, 800f)
                stroke(c, floatArrayOf(360f, 800f, 340f, 860f, 420f, 900f), animal.fur, 64f)
                c.restore()
                c.save()
                c.rotate(-35f * sin(p * PI.toFloat()), 640f, 800f)
                stroke(c, floatArrayOf(640f, 800f, 660f, 860f, 580f, 900f), animal.fur, 64f)
                c.restore()
                circle(c, 410f, 700f, 13f, Color.parseColor("#F6D15C"))
                circle(c, 590f, 700f, 13f, Color.parseColor("#F6D15C"))
            }
            Animal.PARROT -> {
                val flap = sin(p * PI.toFloat() * 8f) * 42f
                for (side in intArrayOf(-1, 1)) {
                    c.save()
                    c.rotate(side * flap, 500f + side * 170f, 780f)
                    oval(c, 500f + side * 170f, 780f, 58f, 150f, Color.parseColor("#27864F"), null)
                    detail.color = Color.parseColor("#F2D14A")
                    detail.strokeWidth = 12f
                    c.drawLine(500f + side * 170f, 700f, 500f + side * 160f, 850f, detail)
                    c.restore()
                }
            }
            Animal.TIGER -> {
                for (i in 0..2) {
                    outline.color = Color.parseColor("#FFF1C9")
                    outline.strokeWidth = 9f
                    val r = 48f + i * 27f + p * 20f
                    rect.set(500f - r, 570f - r, 500f + r, 570f + r)
                    c.drawArc(rect, 215f, 110f, false, outline)
                }
            }
            Animal.RABBIT -> {
                circle(c, 470f, 300f - 100f * sin(PI.toFloat() * p), 8f, Color.WHITE)
                circle(c, 530f, 300f - 100f * sin(PI.toFloat() * p), 8f, Color.WHITE)
            }
            Animal.PANDA -> {
                for (i in 0..3) {
                    val a = p * PI.toFloat() * 2f + i * PI.toFloat() / 2f
                    circle(c, 500f + cos(a) * 185f, 850f + sin(a) * 220f, 11f, Color.parseColor("#F7D76B"))
                }
            }
            Animal.PIG -> {
                for (i in 0..2) {
                    val t = (p * 3f + i * 0.33f) % 1f
                    val dir = if (i % 2 == 0) -1f else 1f
                    circle(c, 500f + dir * (85f + t * 140f), 640f + t * 60f, 14f + t * 22f, Color.argb((200 * (1f - t)).toInt(), 255, 255, 255))
                }
            }
            Animal.FROG -> {
                val f = sin(PI.toFloat() * p)
                val tx = 500f + (660f - 500f) * f
                val ty = 595f + (400f - 595f) * f
                if (p < 0.55f) {
                    circle(c, 660f, 400f + sin(time * 20f) * 6f, 11f, Color.parseColor("#2B2B2B"))
                    circle(c, 650f, 388f, 9f, Color.argb(150, 255, 255, 255))
                    circle(c, 672f, 388f, 9f, Color.argb(150, 255, 255, 255))
                }
                detail.color = Color.parseColor("#E26A7E")
                detail.strokeWidth = 24f
                c.drawLine(500f, 595f, tx, ty, detail)
                circle(c, tx, ty, 17f, Color.parseColor("#E26A7E"))
            }
            Animal.PENGUIN -> {
                val flap = sin(p * PI.toFloat() * 8f) * 32f
                for (side in intArrayOf(-1, 1)) {
                    c.save()
                    c.rotate(side * (28f + flap), 500f + side * 205f, 700f)
                    oval(c, 500f + side * 215f, 850f, 52f, 175f, animal.fur, animal.darkFur)
                    c.restore()
                }
                for (i in 0..5) {
                    val y = 200f + ((p * 900f + i * 190f) % 700f)
                    circle(c, 250f + i * 100f, y, 8f, Color.argb(220, 255, 255, 255))
                }
            }
            Animal.KOALA -> {
                for (i in 0..3) {
                    val t = (p * 1.2f + i * 0.27f) % 1f
                    val cx = 330f + i * 115f + sin(t * 6f + i) * 40f
                    val cy = 150f + t * 520f
                    c.save()
                    c.rotate(sin(t * 8f + i) * 50f, cx, cy)
                    oval(c, cx, cy, 16f, 34f, Color.parseColor("#6FAF5B"), Color.parseColor("#3F7A3A"))
                    c.restore()
                }
            }
            Animal.COW -> {
                c.save()
                c.rotate(sin(p * PI.toFloat() * 10f) * 22f, 500f, 760f)
                oval(c, 500f, 788f, 36f, 36f, Color.parseColor("#F2C94C"), Color.parseColor("#A8791F"))
                circle(c, 500f, 818f, 7f, Color.parseColor("#7A5A1C"))
                c.restore()
                for (i in 0..1) {
                    outline.color = Color.parseColor("#F2C94C")
                    outline.strokeWidth = 8f
                    val r = 60f + i * 30f + p * 20f
                    rect.set(500f - r, 790f - r, 500f + r, 790f + r)
                    c.drawArc(rect, 150f, 40f, false, outline)
                    c.drawArc(rect, 350f, 40f, false, outline)
                }
            }
            Animal.LION -> Unit
        }
    }
}
