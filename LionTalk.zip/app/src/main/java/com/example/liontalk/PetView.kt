package com.example.liontalk

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Lion cub character.
 *
 * Art: har body-part (body, head+mane, paws, tail) ek baar hazaaron fur-strokes se
 * bitmap me paint hota hai (gradient shading + fur texture). Phir har frame par
 * ye bitmaps hilte hain, aur aankhein / munh / moochh / bhauhein live vector se banti hain.
 *
 * Reactions:  SIR tap -> ouch   |  PET tap -> hansi (tickle)  |  HAATH tap -> wave  |  POONCH tap -> wag
 */
class PetView(ctx: Context, private val synth: Synth) : View(ctx) {

    private class Part(val bmp: Bitmap, val left: Float, val top: Float, val w: Float, val h: Float)
    private class Parts(val tail: Part, val body: Part, val pawL: Part, val pawR: Part, val head: Part)
    private enum class Act { NONE, HEAD, BELLY, PAW, TAIL }

    // design space 1000 x 1300
    private val DW = 1000f
    private val DH = 1300f
    private val TWO_PI = (2.0 * PI).toFloat()
    private var s = 1f
    private var ox = 0f
    private var oy = 0f

    @Volatile private var parts: Parts? = null
    @Volatile private var buildId = 0

    // ---- paints ----
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val wallPaint = Paint()
    private val floorPaint = Paint()
    private val vigPaint = Paint()
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 2f; color = Color.parseColor("#33000000")
    }
    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
    private val tmpR = RectF()

    private val irisPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = RadialGradient(
            0f, 0f, 32f,
            intArrayOf(Color.parseColor("#F4C84E"), Color.parseColor("#D48C14"), Color.parseColor("#5E3507")),
            floatArrayOf(0f, 0.62f, 1f), Shader.TileMode.CLAMP
        )
    }
    private val darkFill = Paint().apply { color = Color.parseColor("#140C05") }
    private val pupilPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#060301") }
    private val hiPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; alpha = 240 }
    private val hiPaint2 = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; alpha = 170 }
    private val lidPaint = Paint().apply {
        shader = LinearGradient(0f, -34f, 0f, 4f, 0xCC000000.toInt(), 0x00000000, Shader.TileMode.CLAMP)
    }
    private val outlinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 4f; color = Color.parseColor("#2A1608")
        strokeJoin = Paint.Join.ROUND; strokeCap = Paint.Cap.ROUND
    }
    private val linerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 6f; color = Color.parseColor("#2A1608")
        strokeCap = Paint.Cap.ROUND
    }
    private val browPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 8f; color = Color.parseColor("#6B4220"); alpha = 190
        strokeCap = Paint.Cap.ROUND
    }
    private val mouthLine = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 4.5f; color = Color.parseColor("#4A2320")
        strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val mouthFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#4D1019") }
    private val tonguePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#DB6B80") }
    private val toothPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#FFF8EA") }
    private val whiskerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 2.6f; color = Color.WHITE; alpha = 215
        strokeCap = Paint.Cap.ROUND
    }
    private val eyePath = Path()
    private val browPath = Path()
    private val mPath = Path()
    private val wPath = Path()

    // ---- animation state ----
    private var react = Act.NONE
    private var reactStart = 0L
    private var pawSide = 1
    private var nextBlink = 0L
    private var blinkStart = 0L
    private var lookX = 0f
    private var lookY = 0f
    private var lookTx = 0f
    private var lookTy = 0f

    private var stBsx = 1f
    private var stBsy = 1f
    private var stHr = 0f
    private var stHdy = 0f
    private var stOpen = 1f
    private var stHappy = 0f
    private var stMouth = 0f
    private var stSmile = 0.3f
    private var stBrow = 0f
    private var stTilt = 0f
    private var stPup = 0.45f
    private var stTail = 0f
    private var stPl = 0f
    private var stPr = 0f
    private var stLx = 0f
    private var stLy = 0f

    // =====================================================================
    //  size + build
    // =====================================================================

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        s = min(w / DW, h / DH)
        ox = (w - DW * s) / 2f
        oy = (h - DH * s) * 0.45f
        val horizon = oy + 1090f * s
        wallPaint.shader = LinearGradient(
            0f, 0f, 0f, horizon,
            Color.parseColor("#F7E8CF"), Color.parseColor("#E2C08A"), Shader.TileMode.CLAMP
        )
        floorPaint.shader = LinearGradient(
            0f, horizon, 0f, h.toFloat(),
            Color.parseColor("#C1925D"), Color.parseColor("#6F4826"), Shader.TileMode.CLAMP
        )
        vigPaint.shader = RadialGradient(
            w / 2f, h * 0.48f, max(w, h) * 0.8f,
            intArrayOf(0x00000000, 0x00000000, 0x77000000),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        val id = ++buildId
        parts = null
        Thread {
            val p = buildParts()
            if (id == buildId) {
                parts = p
                postInvalidate()
            }
        }.start()
    }

    private fun makePart(left: Float, top: Float, w: Float, h: Float, draw: (Canvas) -> Unit): Part {
        val bw = max(1, ceil(w * s).toInt())
        val bh = max(1, ceil(h * s).toInt())
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.scale(s, s)
        c.translate(-left, -top)
        draw(c)
        return Part(bmp, left, top, w, h)
    }

    private fun buildParts(): Parts {
        val tail = makePart(650f, 740f, 320f, 440f) { drawTailArt(it) }
        val body = makePart(180f, 520f, 640f, 760f) { drawBodyArt(it) }
        val pawL = makePart(320f, 960f, 180f, 310f) { drawLegArt(it, 410f, 21) }
        val pawR = makePart(500f, 960f, 180f, 310f) { drawLegArt(it, 590f, 22) }
        val head = makePart(170f, 140f, 660f, 600f) { drawHeadArt(it) }
        return Parts(tail, body, pawL, pawR, head)
    }

    // =====================================================================
    //  painting helpers
    // =====================================================================

    private fun pal(vararg hex: String) = IntArray(hex.size) { Color.parseColor(hex[it]) }

    private fun fur(
        c: Canvas, cx: Float, cy: Float, rx: Float, ry: Float, n: Int, seed: Int,
        cols: IntArray, lenMin: Float, lenMax: Float, wMin: Float, wMax: Float,
        gravity: Float, outward: Float, radMin: Float, radMax: Float,
        aMin: Int = 90, aMax: Int = 190
    ) {
        val r = Random(seed)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        for (i in 0 until n) {
            val ang = r.nextFloat() * TWO_PI
            val rad = sqrt(radMin * radMin + r.nextFloat() * (radMax * radMax - radMin * radMin))
            val px = cx + cos(ang) * rx * rad
            val py = cy + sin(ang) * ry * rad
            var dx = cos(ang) * outward
            var dy = sin(ang) * outward + gravity
            val m = hypot(dx, dy)
            if (m < 0.001f) { dx = 0f; dy = 1f } else { dx /= m; dy /= m }
            val j = (r.nextFloat() - 0.5f) * 0.9f
            val cj = cos(j)
            val sj = sin(j)
            val nx = dx * cj - dy * sj
            val ny = dx * sj + dy * cj
            val len = lenMin + r.nextFloat() * (lenMax - lenMin)
            p.color = cols[r.nextInt(cols.size)]
            p.alpha = aMin + r.nextInt(max(1, aMax - aMin))
            p.strokeWidth = wMin + r.nextFloat() * (wMax - wMin)
            c.drawLine(px, py, px + nx * len, py + ny * len, p)
        }
    }

    private fun ovalBase(c: Canvas, cx: Float, cy: Float, rx: Float, ry: Float, light: Int, base: Int, dark: Int) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = RadialGradient(
            cx - rx * 0.3f, cy - ry * 0.35f, max(rx, ry) * 1.25f,
            intArrayOf(light, base, dark), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        c.drawOval(RectF(cx - rx, cy - ry, cx + rx, cy + ry), p)
    }

    private fun clipOval(c: Canvas, cx: Float, cy: Float, rx: Float, ry: Float, block: () -> Unit) {
        val path = Path()
        path.addOval(RectF(cx - rx, cy - ry, cx + rx, cy + ry), Path.Direction.CW)
        c.save()
        c.clipPath(path)
        block()
        c.restore()
    }

    // =====================================================================
    //  ART: tail, body, legs, head
    // =====================================================================

    private val tanL = Color.parseColor("#EBCB8E")
    private val tanM = Color.parseColor("#C9954F")
    private val tanD = Color.parseColor("#8A5A2B")

    private fun drawTailArt(c: Canvas) {
        val path = Path()
        path.moveTo(690f, 1105f)
        path.cubicTo(870f, 1130f, 940f, 1000f, 895f, 860f)
        val sp = Paint(Paint.ANTI_ALIAS_FLAG)
        sp.style = Paint.Style.STROKE
        sp.strokeCap = Paint.Cap.ROUND
        sp.color = tanD; sp.strokeWidth = 46f; c.drawPath(path, sp)
        sp.color = tanM; sp.strokeWidth = 38f; c.drawPath(path, sp)
        sp.color = tanL; sp.alpha = 90; sp.strokeWidth = 12f; c.drawPath(path, sp)

        val cols = pal("#E3BB7C", "#C9954F", "#B5813F", "#9A6A33", "#F0D29A")
        val pm = PathMeasure(path, false)
        val pos = FloatArray(2)
        val tan = FloatArray(2)
        val rr = Random(5)
        val lp = Paint(Paint.ANTI_ALIAS_FLAG)
        lp.style = Paint.Style.STROKE
        lp.strokeCap = Paint.Cap.ROUND
        for (i in 0 until 320) {
            pm.getPosTan(rr.nextFloat() * pm.length, pos, tan)
            val nx = -tan[1]
            val ny = tan[0]
            val sd = rr.nextFloat() * 2f - 1f
            val px = pos[0] + nx * sd * 17f
            val py = pos[1] + ny * sd * 17f
            val dx = tan[0] * 0.6f + nx * sd * 0.6f
            val dy = tan[1] * 0.6f + ny * sd * 0.6f
            val l = 9f + rr.nextFloat() * 9f
            lp.color = cols[rr.nextInt(cols.size)]
            lp.alpha = 120 + rr.nextInt(80)
            lp.strokeWidth = 1.5f + rr.nextFloat() * 1.5f
            c.drawLine(px, py, px + dx * l, py + dy * l, lp)
        }
        // tuft
        val dark = pal("#3E2210", "#5A3216", "#7A4520", "#2E190C")
        fur(c, 895f, 842f, 44f, 66f, 260, 6, dark, 14f, 30f, 2f, 3.6f, -0.15f, 0.9f, 0.7f, 1f, 130, 230)
        ovalBase(c, 895f, 842f, 38f, 58f, Color.parseColor("#7A4520"), Color.parseColor("#55301A"), Color.parseColor("#2E190C"))
        clipOval(c, 895f, 842f, 38f, 58f) {
            fur(c, 895f, 842f, 38f, 58f, 500, 8, dark, 10f, 24f, 1.6f, 3f, 0.4f, 0.8f, 0f, 1f, 110, 220)
        }
    }

    private fun drawBodyArt(c: Canvas) {
        val dark = pal("#9A6A33", "#8A5A2B", "#B5813F", "#7A4D24")
        val cols = pal("#E3BB7C", "#C9954F", "#B5813F", "#9A6A33", "#F0D29A")
        // fuzzy rim
        fur(c, 500f, 900f, 275f, 330f, 520, 11, dark, 14f, 30f, 1.6f, 3.2f, 0.5f, 0.9f, 0.9f, 1.0f)
        ovalBase(c, 500f, 900f, 272f, 327f, tanL, tanM, tanD)
        clipOval(c, 500f, 900f, 272f, 327f) {
            fur(c, 500f, 900f, 275f, 330f, 2600, 12, cols, 12f, 26f, 1.5f, 3f, 0.6f, 0.5f, 0f, 1f)
            // belly
            val bp = Paint(Paint.ANTI_ALIAS_FLAG)
            bp.shader = RadialGradient(
                500f, 950f, 230f,
                intArrayOf(Color.parseColor("#F4E5C3"), Color.parseColor("#EBCB8E"), 0x00EBCB8E),
                floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP
            )
            c.drawOval(RectF(350f, 740f, 650f, 1160f), bp)
            val light = pal("#F6E9CC", "#EBD3A0", "#F0DDB8", "#E3C48C")
            fur(c, 500f, 950f, 150f, 210f, 1000, 13, light, 10f, 20f, 1.4f, 2.6f, 0.7f, 0.6f, 0f, 0.92f, 70, 150)
        }
    }

    private fun drawLegArt(c: Canvas, cx: Float, seed: Int) {
        val cy = 1120f
        val dark = pal("#9A6A33", "#8A5A2B", "#B5813F")
        val cols = pal("#E3BB7C", "#C9954F", "#B5813F", "#F0D29A")
        fur(c, cx, cy, 60f, 125f, 160, seed, dark, 10f, 20f, 1.4f, 2.8f, 0.8f, 0.8f, 0.9f, 1f)
        ovalBase(c, cx, cy, 58f, 121f, tanL, tanM, tanD)
        clipOval(c, cx, cy, 58f, 121f) {
            fur(c, cx, cy, 60f, 125f, 700, seed + 10, cols, 10f, 20f, 1.4f, 2.6f, 0.8f, 0.4f, 0f, 1f)
            val tip = Paint(Paint.ANTI_ALIAS_FLAG)
            tip.color = Color.parseColor("#F0DDB8"); tip.alpha = 120
            c.drawOval(RectF(cx - 50f, 1185f, cx + 50f, 1250f), tip)
        }
        val toe = Paint(Paint.ANTI_ALIAS_FLAG)
        toe.style = Paint.Style.STROKE
        toe.strokeCap = Paint.Cap.ROUND
        toe.strokeWidth = 3.5f
        toe.color = Color.parseColor("#5E3A1C")
        toe.alpha = 130
        for (i in -1..1) c.drawLine(cx + i * 20f, 1205f, cx + i * 20f, 1238f, toe)
    }

    private fun drawEar(c: Canvas, cx: Float, cy: Float, seed: Int) {
        val cols = pal("#E3BB7C", "#C9954F", "#B5813F", "#9A6A33")
        fur(c, cx, cy, 58f, 58f, 120, seed, cols, 8f, 16f, 1.5f, 2.6f, 0.3f, 1f, 0.9f, 1f)
        ovalBase(c, cx, cy, 56f, 56f, tanL, tanM, tanD)
        clipOval(c, cx, cy, 56f, 56f) {
            fur(c, cx, cy, 58f, 58f, 320, seed + 1, cols, 8f, 16f, 1.3f, 2.4f, 0.3f, 0.6f, 0f, 1f)
        }
        ovalBase(c, cx, cy + 6f, 32f, 36f, Color.parseColor("#E3B3A3"), Color.parseColor("#C98A7A"), Color.parseColor("#8E5348"))
        val cream = pal("#F6E7C6", "#F0DDB8", "#E8CFA0")
        clipOval(c, cx, cy + 6f, 32f, 36f) {
            fur(c, cx, cy + 6f, 32f, 36f, 160, seed + 2, cream, 6f, 12f, 1.1f, 2f, 0.4f, 0.5f, 0f, 1f, 70, 150)
        }
    }

    private fun drawHeadArt(c: Canvas) {
        // ears (mane ke peeche)
        drawEar(c, 335f, 238f, 31)
        drawEar(c, 665f, 238f, 32)

        // mane
        val maneCols = pal("#5E3517", "#7A4520", "#A8672A", "#D49A4A", "#4E2B12", "#8A5224")
        fur(c, 500f, 450f, 262f, 248f, 700, 33, maneCols, 30f, 62f, 2f, 4f, 0.25f, 1f, 0.82f, 1f, 110, 220)
        ovalBase(c, 500f, 450f, 258f, 244f, Color.parseColor("#A8672A"), Color.parseColor("#7A4520"), Color.parseColor("#4E2B12"))
        clipOval(c, 500f, 450f, 258f, 244f) {
            fur(c, 500f, 450f, 262f, 248f, 3000, 34, maneCols, 26f, 52f, 2f, 3.8f, 0.2f, 0.9f, 0f, 1f, 100, 210)
        }

        // face
        val faceCols = pal("#EFD6A0", "#E0B676", "#D0A25C", "#C9954F", "#F3E0B4")
        ovalBase(c, 500f, 440f, 195f, 178f, Color.parseColor("#EDD39B"), Color.parseColor("#D0A25C"), Color.parseColor("#A8773D"))
        clipOval(c, 500f, 440f, 195f, 178f) {
            fur(c, 500f, 440f, 197f, 180f, 2400, 35, faceCols, 7f, 15f, 1.2f, 2.4f, 0.3f, 0.9f, 0f, 1f)
            // maathe par halke daag
            val mk = Paint(Paint.ANTI_ALIAS_FLAG)
            mk.style = Paint.Style.STROKE; mk.strokeCap = Paint.Cap.ROUND
            mk.strokeWidth = 5f; mk.color = tanD; mk.alpha = 55
            for (i in -1..1) c.drawLine(500f + i * 32f, 296f, 500f + i * 30f, 336f - abs(i) * 8f, mk)
        }
        // face ki kinara mane se mile
        fur(c, 500f, 440f, 195f, 178f, 520, 36, faceCols, 14f, 26f, 1.4f, 2.6f, 0.2f, 1f, 0.88f, 1f, 70, 140)

        // chin + muzzle
        val cream = pal("#FBF0D6", "#F0DDB8", "#E8CFA0", "#F6E7C6")
        ovalBase(c, 500f, 590f, 56f, 42f, Color.parseColor("#F6E7C6"), Color.parseColor("#E7CFA0"), Color.parseColor("#C9AA78"))
        clipOval(c, 500f, 590f, 56f, 42f) {
            fur(c, 500f, 590f, 58f, 44f, 200, 37, cream, 5f, 10f, 1f, 1.8f, 0.5f, 0.7f, 0f, 1f, 80, 170)
        }
        for (mx in floatArrayOf(455f, 545f)) {
            ovalBase(c, mx, 520f, 74f, 58f, Color.parseColor("#FBF0D6"), Color.parseColor("#F0DDB8"), Color.parseColor("#D4B98A"))
            clipOval(c, mx, 520f, 74f, 58f) {
                fur(c, mx, 520f, 76f, 60f, 380, 38 + mx.toInt(), cream, 6f, 12f, 1.1f, 2f, 0.4f, 0.9f, 0f, 1f, 80, 170)
            }
        }
        // moochh ke dots
        val dot = Paint(Paint.ANTI_ALIAS_FLAG)
        dot.color = Color.parseColor("#6B4220"); dot.alpha = 120
        for (i in 0..2) {
            val dx = 418f + (i % 2) * 16f
            val dy = 500f + i * 14f
            c.drawCircle(dx, dy, 2.8f, dot)
            c.drawCircle(1000f - dx, dy, 2.8f, dot)
        }

        // nose
        val nose = Path()
        nose.moveTo(462f, 470f)
        nose.quadTo(500f, 456f, 538f, 470f)
        nose.quadTo(530f, 505f, 500f, 516f)
        nose.quadTo(470f, 505f, 462f, 470f)
        nose.close()
        val np = Paint(Paint.ANTI_ALIAS_FLAG)
        np.shader = RadialGradient(
            490f, 478f, 52f,
            intArrayOf(Color.parseColor("#D98A80"), Color.parseColor("#B0605A"), Color.parseColor("#7A3A36")),
            floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP
        )
        c.drawPath(nose, np)
        val ns = Paint(Paint.ANTI_ALIAS_FLAG)
        ns.style = Paint.Style.STROKE; ns.strokeWidth = 3f; ns.color = Color.parseColor("#4A2320")
        ns.strokeJoin = Paint.Join.ROUND
        c.drawPath(nose, ns)
        val hl = Paint(Paint.ANTI_ALIAS_FLAG)
        hl.color = Color.WHITE; hl.alpha = 110
        c.drawOval(RectF(478f, 468f, 506f, 478f), hl)
        // nostrils
        val nostril = Paint(Paint.ANTI_ALIAS_FLAG)
        nostril.color = Color.parseColor("#3A1A18"); nostril.alpha = 160
        c.drawOval(RectF(474f, 492f, 487f, 500f), nostril)
        c.drawOval(RectF(513f, 492f, 526f, 500f), nostril)
    }

    // =====================================================================
    //  animation state
    // =====================================================================

    private fun smooth(x: Float): Float {
        val v = x.coerceIn(0f, 1f)
        return v * v * (3f - 2f * v)
    }

    private fun env(p: Float, a: Float, b: Float): Float = min(smooth(p / a), smooth((1f - p) / b))

    private fun update(now: Long) {
        val pi = PI.toFloat()
        val t = now / 1000f
        var bsx = 1f - 0.006f * sin(t * 2.2f)
        var bsy = 1f + 0.012f * sin(t * 2.2f)
        var hr = 1.8f * sin(t * 0.9f)
        var hdy = 0f
        var op = 1f
        var hp = 0f
        var mo = 0f
        var sm = 0.3f
        var br = 0f
        var tl = 0f
        var pu = 0.45f
        var ta = 12f * sin(t * 1.6f)
        var pl = 0f
        var pr = 0f
        var rlx = 0f
        var rly = 0f

        lookX += (lookTx - lookX) * 0.18f
        lookY += (lookTy - lookY) * 0.18f
        hr += lookX * 4f

        if (now >= nextBlink) {
            blinkStart = now
            nextBlink = now + 2200L + Random.nextInt(3200)
        }
        val bp = (now - blinkStart) / 170f
        if (bp in 0f..1f) op = 1f - sin(bp * pi)

        if (react != Act.NONE) {
            val dur = when (react) {
                Act.HEAD -> 1200f
                Act.BELLY -> 1800f
                Act.PAW -> 2000f
                Act.TAIL -> 1400f
                else -> 1f
            }
            val tt = (now - reactStart) / 1000f
            val p = (now - reactStart) / dur
            if (p >= 1f) {
                react = Act.NONE
            } else when (react) {
                Act.HEAD -> {
                    val d = exp(-tt * 5f)
                    hr += 14f * sin(tt * 26f) * (1f - p)
                    hdy = 22f * exp(-tt * 8f)
                    op = if (p < 0.6f) 0f else smooth((p - 0.6f) / 0.4f)
                    mo = 0.7f * smooth((0.85f - p) / 0.35f)
                    br = 0.6f
                    tl = 1f - p
                    pu = 1f
                    sm = 0f
                    bsy = 1f - 0.05f * d
                    bsx = 1f + 0.03f * d
                }
                Act.BELLY -> {
                    val bounce = sin(tt * 28f)
                    val fade = 1f - smooth((p - 0.8f) / 0.2f)
                    bsy = 1f + 0.05f * bounce * fade
                    bsx = 1f - 0.03f * bounce * fade
                    hp = fade
                    mo = (0.55f + 0.35f * sin(tt * 28f - 1.3f)) * fade
                    hr += 7f * sin(tt * 14f) * fade
                    hdy = -8f * abs(bounce) * fade
                    pl = 10f * sin(tt * 28f) * fade
                    pr = -10f * sin(tt * 28f + 1f) * fade
                    ta = ta * (1f - fade) + 30f * sin(tt * 20f) * fade
                    sm = 1f
                }
                Act.PAW -> {
                    val e = env(p, 0.1f, 0.15f)
                    val wave = -(42f + 22f * sin(tt * 13f)) * e
                    if (pawSide > 0) pr = wave else pl = -wave
                    mo = (0.25f + 0.12f * sin(tt * 13f)) * e
                    sm = 1f
                    hr += 6f * pawSide * e
                    rlx = 0.7f * pawSide * e
                    pu = 0.6f
                }
                Act.TAIL -> {
                    val e = env(p, 0.08f, 0.2f)
                    ta = 38f * sin(tt * 22f) * e + ta * (1f - e)
                    hr += -6f * e
                    rlx = 0.9f * e
                    rly = 0.3f * e
                    mo = 0.25f * e
                    sm = 1f
                }
                else -> {}
            }
        }

        stBsx = bsx; stBsy = bsy; stHr = hr; stHdy = hdy
        stOpen = op; stHappy = hp; stMouth = mo; stSmile = sm
        stBrow = br; stTilt = tl; stPup = pu
        stTail = ta; stPl = pl; stPr = pr
        stLx = (lookX + rlx).coerceIn(-1.2f, 1.2f)
        stLy = (lookY + rly).coerceIn(-1.2f, 1.2f)
    }

    // =====================================================================
    //  drawing
    // =====================================================================

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        drawBackground(c)
        val p = parts
        if (p != null) {
            update(now)
            drawPet(c, p, now)
        }
        postInvalidateOnAnimation()
    }

    private fun drawBackground(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val horizon = oy + 1090f * s
        c.drawRect(0f, 0f, w, horizon, wallPaint)
        c.drawRect(0f, horizon, w, h, floorPaint)
        shadowPaint.alpha = 70
        c.drawRect(0f, horizon - 10f * s, w, horizon + 4f * s, shadowPaint)
        for (i in 1..6) {
            val f = i / 6f
            val y = horizon + (h - horizon) * f * f
            c.drawLine(0f, y, w, y, linePaint)
        }
        c.drawRect(0f, 0f, w, h, vigPaint)
    }

    private fun drawPart(c: Canvas, p: Part) {
        tmpR.set(p.left, p.top, p.left + p.w, p.top + p.h)
        c.drawBitmap(p.bmp, null, tmpR, bmpPaint)
    }

    private fun drawPet(c: Canvas, ps: Parts, now: Long) {
        val t = now / 1000f
        c.save()
        c.translate(ox, oy)
        c.scale(s, s)

        // zameen par parchhai
        for (i in 0..3) {
            shadowPaint.alpha = 26
            val k = 1f - i * 0.12f
            tmpR.set(500f - 320f * k, 1236f - 38f * k, 500f + 320f * k, 1236f + 38f * k)
            c.drawOval(tmpR, shadowPaint)
        }

        c.save()
        c.scale(stBsx, stBsy, 500f, 1235f)

        c.save(); c.rotate(stTail, 690f, 1105f); drawPart(c, ps.tail); c.restore()
        drawPart(c, ps.body)
        c.save(); c.rotate(stPl, 420f, 990f); drawPart(c, ps.pawL); c.restore()
        c.save(); c.rotate(stPr, 580f, 990f); drawPart(c, ps.pawR); c.restore()

        c.save()
        c.translate(0f, stHdy)
        c.rotate(stHr, 500f, 650f)
        drawPart(c, ps.head)
        drawBrows(c)
        drawEye(c, 418f, 398f, -1)
        drawEye(c, 582f, 398f, 1)
        drawWhiskers(c, t)
        drawMouth(c)
        c.restore()

        c.restore()
        c.restore()
    }

    private fun drawBrows(c: Canvas) {
        for (side in intArrayOf(-1, 1)) {
            val cx = 500f + side * 82f
            val y = 342f - stBrow * 16f
            browPath.reset()
            browPath.moveTo(cx - side * 36f, y - stTilt * 14f)
            browPath.quadTo(cx, y - 10f - stBrow * 4f, cx + side * 40f, y + 2f)
            c.drawPath(browPath, browPaint)
        }
    }

    private fun drawEye(c: Canvas, cx: Float, cy: Float, side: Int) {
        c.save()
        c.translate(cx, cy)
        c.rotate(-side * 5f)
        val rx = 40f
        val effOpen = stOpen * (1f - (stHappy * 1.8f).coerceIn(0f, 1f))
        if (effOpen > 0.06f) {
            val ryo = 30f * effOpen
            eyePath.reset()
            eyePath.moveTo(-rx, 0f)
            eyePath.quadTo(0f, -2f * ryo, rx, 0f)
            eyePath.quadTo(0f, 1.7f * ryo, -rx, 0f)
            eyePath.close()
            c.save()
            c.clipPath(eyePath)
            c.drawRect(-rx - 4f, -40f, rx + 4f, 40f, darkFill)
            c.save()
            c.translate(stLx * 10f, stLy * 6f)
            c.drawCircle(0f, 0f, 32f, irisPaint)
            val pw = 5f + 9f * stPup
            tmpR.set(-pw, -26f, pw, 26f)
            c.drawOval(tmpR, pupilPaint)
            c.drawCircle(-11f, -11f, 8f, hiPaint)
            c.drawCircle(11f, 9f, 4f, hiPaint2)
            c.restore()
            c.drawRect(-rx - 4f, -40f, rx + 4f, 6f, lidPaint)
            c.restore()
            c.drawPath(eyePath, outlinePaint)
            c.drawLine(side * rx, 0f, side * (rx + 18f), -9f, linerPaint)
        } else if (stHappy > 0.3f) {
            eyePath.reset()
            eyePath.moveTo(-rx * 0.9f, 8f)
            eyePath.quadTo(0f, -36f, rx * 0.9f, 8f)
            c.drawPath(eyePath, outlinePaint.also { it.strokeWidth = 8f })
            outlinePaint.strokeWidth = 4f
        } else {
            eyePath.reset()
            eyePath.moveTo(-rx, 2f)
            eyePath.quadTo(0f, 12f, rx, 2f)
            c.drawPath(eyePath, outlinePaint.also { it.strokeWidth = 5f })
            outlinePaint.strokeWidth = 4f
            c.drawLine(side * rx, 2f, side * (rx + 18f), -7f, linerPaint)
        }
        c.restore()
    }

    private fun drawWhiskers(c: Canvas, t: Float) {
        for (side in intArrayOf(-1, 1)) {
            for (i in 0..2) {
                val sx = 500f + side * 58f
                val sy = 500f + i * 13f
                val ex = 500f + side * (215f + i * 8f)
                val ey = 452f + i * 44f
                val wob = sin(t * 1.7f + i) * 2.5f + (if (react != Act.NONE) sin(t * 20f + i) * 3f else 0f)
                wPath.reset()
                wPath.moveTo(sx, sy)
                wPath.quadTo(500f + side * 140f, sy - 28f + wob, ex, ey)
                c.drawPath(wPath, whiskerPaint)
            }
        }
    }

    private fun drawMouth(c: Canvas) {
        val m = stMouth
        val sm = stSmile
        if (m < 0.06f) {
            mPath.reset()
            mPath.moveTo(500f, 516f)
            mPath.lineTo(500f, 540f)
            mPath.moveTo(500f, 540f)
            mPath.quadTo(480f, 566f + sm * 8f, 444f, 548f - sm * 10f)
            mPath.moveTo(500f, 540f)
            mPath.quadTo(520f, 566f + sm * 8f, 556f, 548f - sm * 10f)
            c.drawPath(mPath, mouthLine)
        } else {
            val h = 20f + 70f * m
            c.drawLine(500f, 516f, 500f, 542f, mouthLine)
            mPath.reset()
            mPath.moveTo(452f, 544f)
            mPath.quadTo(500f, 538f, 548f, 544f)
            mPath.cubicTo(566f, 544f + 1.33f * h, 434f, 544f + 1.33f * h, 452f, 544f)
            mPath.close()
            c.drawPath(mPath, mouthFill)
            c.save()
            c.clipPath(mPath)
            tmpR.set(464f, 544f + h * 0.78f - h * 0.42f, 536f, 544f + h * 0.78f + h * 0.42f)
            c.drawOval(tmpR, tonguePaint)
            c.restore()
            val tooth = 8f + 10f * min(1f, m * 2f)
            val tp = Path()
            tp.moveTo(464f, 545f); tp.lineTo(480f, 545f); tp.lineTo(472f, 545f + tooth); tp.close()
            tp.moveTo(520f, 545f); tp.lineTo(536f, 545f); tp.lineTo(528f, 545f + tooth); tp.close()
            c.drawPath(tp, toothPaint)
            c.drawPath(mPath, mouthLine)
        }
    }

    // =====================================================================
    //  touch
    // =====================================================================

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x = (e.x - ox) / s
        val y = (e.y - oy) / s
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lookTx = ((x - 500f) / 450f).coerceIn(-1f, 1f)
                lookTy = ((y - 450f) / 450f).coerceIn(-1f, 1f)
                hit(x, y)
            }
            MotionEvent.ACTION_MOVE -> {
                lookTx = ((x - 500f) / 450f).coerceIn(-1f, 1f)
                lookTy = ((y - 450f) / 450f).coerceIn(-1f, 1f)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                lookTx = 0f
                lookTy = 0f
            }
        }
        return true
    }

    private fun inEllipse(x: Float, y: Float, cx: Float, cy: Float, rx: Float, ry: Float): Boolean {
        val a = (x - cx) / rx
        val b = (y - cy) / ry
        return a * a + b * b <= 1f
    }

    private fun hit(x: Float, y: Float) {
        when {
            x in 335f..480f && y in 960f..1250f -> start(Act.PAW, -1, "hello")      // baaya haath
            x in 520f..665f && y in 960f..1250f -> start(Act.PAW, 1, "hello")       // daaya haath
            inEllipse(x, y, 500f, 450f, 265f, 255f) -> start(Act.HEAD, 0, "ouch")   // sir
            inEllipse(x, y, 500f, 920f, 200f, 230f) -> start(Act.BELLY, 0, "giggle") // pet
            x in 720f..950f && y in 780f..1160f -> start(Act.TAIL, 0, "chirp")      // poonch
        }
    }

    private fun start(a: Act, side: Int, sound: String) {
        react = a
        pawSide = if (side == 0) 1 else side
        reactStart = SystemClock.uptimeMillis()
        synth.play(sound)
        performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
    }
}
