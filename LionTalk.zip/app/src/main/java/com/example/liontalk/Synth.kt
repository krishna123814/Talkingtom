package com.example.liontalk

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Collections
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.tanh

/**
 * Awaazein code se banti hain (koi audio file nahi chahiye).
 * Glottal-style harmonic source + do formant (aa/ee/oo) = meow jaisi awaaz.
 * Baad me asli recorded meow .wav chahiye to res/raw me daal ke yahi jagah badal sakte hain.
 */
class Synth(private val ctx: Context) {

    private val sr = 22050
    @Volatile private var pool: SoundPool? = null
    private val ids = ConcurrentHashMap<String, Int>()
    private val loaded = Collections.synchronizedSet(HashSet<Int>())

    fun init() {
        Thread {
            try {
                val attrs = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
                val pl = SoundPool.Builder().setMaxStreams(4).setAudioAttributes(attrs).build()
                pl.setOnLoadCompleteListener { _, id, status -> if (status == 0) loaded.add(id) }
                pool = pl
                val sounds = listOf(
                    "ouch" to ouch(),
                    "giggle" to giggle(),
                    "hello" to hello(),
                    "chirp" to chirp()
                )
                for ((name, pcm) in sounds) {
                    val f = File(ctx.cacheDir, "lt_$name.wav")
                    writeWav(f, pcm)
                    ids[name] = pl.load(f.absolutePath, 1)
                }
            } catch (e: Exception) {
                // awaaz na bane to app chalti rahe
            }
        }.start()
    }

    fun play(name: String) {
        val id = ids[name] ?: return
        val pl = pool ?: return
        if (loaded.contains(id)) pl.play(id, 1f, 1f, 1, 0, 1f)
    }

    fun release() {
        pool?.release()
        pool = null
    }

    // ---------------- sounds ----------------

    private fun env(t: Float, dur: Float, att: Float, rel: Float): Float =
        min(1f, t / att) * min(1f, max(0f, (dur - t) / rel))

    /** Sir par tap: chhoti "aow!" cheekh, pitch upar se neeche */
    private fun ouch(): ShortArray {
        val d = 0.5f
        return voice(
            d,
            { t -> 380f + 420f * exp(-t * 7f) },
            { t -> 900f - 300f * t / d },
            { t -> 1700f - 600f * t / d },
            { t -> env(t, d, 0.012f, 0.22f) },
            0.03f, 0.035f
        )
    }

    /** Pet par tap: "ha-ha-ha-ha" hansi (animation ke 4.5 Hz bounce se sync) */
    private fun giggle(): ShortArray {
        val d = 0.95f
        fun k(t: Float): Int = (t / 0.22f).toInt()
        fun loc(t: Float): Float = t - k(t) * 0.22f
        val gate = { t: Float ->
            if (k(t) <= 3 && loc(t) < 0.15f) sin(PI.toFloat() * loc(t) / 0.15f) else 0f
        }
        return voice(
            d,
            { t -> 330f + 28f * k(t) + 50f * loc(t) / 0.15f },
            { _ -> 800f },
            { _ -> 1700f },
            gate,
            0.07f, 0.03f
        )
    }

    /** Haath par tap: "mee-aow" meow (ee -> aa -> oo) */
    private fun hello(): ShortArray {
        val d = 0.95f
        val pi = PI.toFloat()
        return voice(
            d,
            { t -> 430f + 230f * sin(pi * t / d) },
            { t -> 450f + 500f * sin(pi * t / d) },
            { t -> 2000f - 900f * t / d },
            { t -> env(t, d, 0.08f, 0.3f) },
            0.015f, 0.025f
        )
    }

    /** Poonch par tap: rolling "mrrrow" chirp */
    private fun chirp(): ShortArray {
        val d = 0.4f
        val pi = PI.toFloat()
        return voice(
            d,
            { t -> 500f + 350f * t / d },
            { t -> 600f + 300f * t / d },
            { t -> 1800f - 300f * t / d },
            { t -> env(t, d, 0.02f, 0.12f) * (0.65f + 0.35f * sin(2f * pi * 26f * t)) },
            0.02f, 0.01f
        )
    }

    // ---------------- synth core ----------------

    private fun voice(
        dur: Float,
        f0: (Float) -> Float,
        f1: (Float) -> Float,
        f2: (Float) -> Float,
        amp: (Float) -> Float,
        breath: Float,
        vib: Float
    ): ShortArray {
        val n = (dur * sr).toInt()
        val out = ShortArray(n)
        val rnd = java.util.Random(7)
        val twoPi = 2.0 * PI
        val piF = PI.toFloat()
        var phase = 0.0
        for (i in 0 until n) {
            val t = i.toFloat() / sr
            val f = f0(t) * (1f + vib * sin(2f * piF * 5.5f * t))
            phase += f.toDouble() / sr
            val form1 = f1(t)
            val form2 = f2(t)
            var sum = 0f
            for (k in 1..18) {
                val fk = f * k
                if (fk > 6000f) break
                val d1 = (fk - form1) / (form1 * 0.35f + 80f)
                val d2 = (fk - form2) / (form2 * 0.30f + 100f)
                val g = exp(-d1 * d1) + 0.6f * exp(-d2 * d2) + 0.06f / k
                sum += g * sin(twoPi * k * phase).toFloat()
            }
            val noise = (rnd.nextFloat() * 2f - 1f) * breath
            val v = tanh(sum * 0.45f + noise) * amp(t)
            out[i] = (v * 30000f).toInt().toShort()
        }
        return out
    }

    private fun writeWav(f: File, pcm: ShortArray) {
        val dataLen = pcm.size * 2
        val bb = ByteBuffer.allocate(44 + dataLen).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray())
        bb.putInt(36 + dataLen)
        bb.put("WAVE".toByteArray())
        bb.put("fmt ".toByteArray())
        bb.putInt(16)
        bb.putShort(1.toShort())
        bb.putShort(1.toShort())
        bb.putInt(sr)
        bb.putInt(sr * 2)
        bb.putShort(2.toShort())
        bb.putShort(16.toShort())
        bb.put("data".toByteArray())
        bb.putInt(dataLen)
        for (v in pcm) bb.putShort(v)
        FileOutputStream(f).use { it.write(bb.array()) }
    }
}
