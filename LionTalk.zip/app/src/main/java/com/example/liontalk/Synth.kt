package com.example.liontalk

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Collections
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.tanh

/**
 * Awaazein code se banti hain (koi audio file nahi chahiye).
 * Glottal-style harmonic source + do formant (aa/ee/oo) = meow jaisi awaaz.
 * Baad me asli recorded meow .wav chahiye to res/raw me daal ke yahi jagah badal sakte hain.
 */
class Synth(private val ctx: Context) {

    private val sr = 22050
    @Volatile private var pool: SoundPool? = null
    private val ids = ConcurrentHashMap<String, Int>()
    private val loaded = Collections.synchronizedSet(HashSet<Int>())

    fun init() {
        Thread {
            try {
                val attrs = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
                val pl = SoundPool.Builder().setMaxStreams(4).setAudioAttributes(attrs).build()
                pl.setOnLoadCompleteListener { _, id, status -> if (status == 0) loaded.add(id) }
                pool = pl
                val sounds = listOf(
                    "ouch" to ouch(),
                    "giggle" to giggle(),
                    "biggiggle" to bigGiggle(),
                    "hello" to hello(),
                    "chirp" to chirp(),
                    "sneeze" to sneeze(),
                    "ear" to earSqueak(),
                    "spin" to spin(),
                    "apple" to appleBite(),
                    "fish" to fishMew(),
                    "cookie" to cookieCrunch(),
                    "tiger" to animalCall("tiger"),
                    "elephant" to animalCall("elephant"),
                    "monkey" to animalCall("monkey"),
                    "panda" to animalCall("panda"),
                    "rabbit" to animalCall("rabbit"),
                    "cat" to animalCall("cat"),
                    "dog" to animalCall("dog"),
                    "fox" to animalCall("fox"),
                    "bear" to animalCall("bear"),
                    "parrot" to animalCall("parrot"),
                    "pig" to animalCall("pig"),
                    "frog" to animalCall("frog"),
                    "penguin" to animalCall("penguin"),
                    "koala" to animalCall("koala"),
                    "cow" to animalCall("cow")
                )
                val extra = ArrayList<Pair<String, ShortArray>>()
                val variants = listOf("ouch", "giggle", "biggiggle", "squeak", "sneeze", "hello", "chirp")
                for (a in Animal.values()) {
                    if (a == Animal.LION) continue
                    for (v in variants) extra.add((a.soundKey + "_" + v) to animalCall(a.soundKey, v))
                }
                for ((name, pcm) in sounds + extra) {
                    // res/raw/snd_<name>.ogg|wav|mp3 maujood ho to asli recording use hogi, warna code wali awaaz
                    val rid = ctx.resources.getIdentifier("snd_$name", "raw", ctx.packageName)
                    if (rid != 0) {
                        ids[name] = pl.load(ctx, rid, 1)
                        continue
                    }
                    val f = File(ctx.cacheDir, "lt_$name.wav")
                    writeWav(f, pcm)
                    ids[name] = pl.load(f.absolutePath, 1)
                }
            } catch (e: Exception) {
                // awaaz na bane to app chalti rahe
            }
        }.start()
    }

    fun play(name: String) {
        val id = ids[name] ?: return
        val pl = pool ?: return
        if (loaded.contains(id)) pl.play(id, 1f, 1f, 1, 0, 1f)
    }

    fun release() {
        pool?.release()
        pool = null
    }

    // ---------------- sounds ----------------

    private fun env(t: Float, dur: Float, att: Float, rel: Float): Float =
        min(1f, t / att) * min(1f, max(0f, (dur - t) / rel))

    /** Sir par tap: chhoti "aow!" cheekh, pitch upar se neeche */
    private fun ouch(): ShortArray {
        val d = 0.5f
        return voice(
            d,
            { t -> 380f + 420f * exp(-t * 7f) },
            { t -> 900f - 300f * t / d },
            { t -> 1700f - 600f * t / d },
            { t -> env(t, d, 0.012f, 0.22f) },
            0.03f, 0.035f
        )
    }

    /** Pet par tap: "ha-ha-ha-ha" hansi (animation ke 4.5 Hz bounce se sync) */
    private fun giggle(): ShortArray {
        val d = 0.95f
        fun k(t: Float): Int = (t / 0.22f).toInt()
        fun loc(t: Float): Float = t - k(t) * 0.22f
        val gate = { t: Float ->
            if (k(t) <= 3 && loc(t) < 0.15f) sin(PI.toFloat() * loc(t) / 0.15f) else 0f
        }
        return voice(
            d,
            { t -> 330f + 28f * k(t) + 50f * loc(t) / 0.15f },
            { _ -> 800f },
            { _ -> 1700f },
            gate,
            0.07f, 0.03f
        )
    }

    /** Haath par tap: "mee-aow" meow (ee -> aa -> oo) */
    private fun hello(): ShortArray {
        val d = 0.95f
        val pi = PI.toFloat()
        return voice(
            d,
            { t -> 430f + 230f * sin(pi * t / d) },
            { t -> 450f + 500f * sin(pi * t / d) },
            { t -> 2000f - 900f * t / d },
            { t -> env(t, d, 0.08f, 0.3f) },
            0.015f, 0.025f
        )
    }

    /** Poonch par tap: rolling "mrrrow" chirp */
    private fun chirp(): ShortArray {
        val d = 0.4f
        val pi = PI.toFloat()
        return voice(
            d,
            { t -> 500f + 350f * t / d },
            { t -> 600f + 300f * t / d },
            { t -> 1800f - 300f * t / d },
            { t -> env(t, d, 0.02f, 0.12f) * (0.65f + 0.35f * sin(2f * pi * 26f * t)) },
            0.02f, 0.01f
        )
    }

    /** Teen baar tickle karne par lambi, tez hansi. */
    private fun bigGiggle(): ShortArray {
        val d = 1.5f
        fun k(t: Float) = (t / 0.23f).toInt()
        fun local(t: Float) = t - k(t) * 0.23f
        val gate = { t: Float ->
            if (k(t) <= 5 && local(t) < 0.17f) sin(PI.toFloat() * local(t) / 0.17f) else 0f
        }
        return voice(
            d,
            { t -> 430f + 35f * k(t) + 70f * local(t) / 0.17f },
            { _ -> 980f },
            { _ -> 2050f },
            gate,
            0.08f, 0.045f
        )
    }

    private fun sneeze(): ShortArray {
        val d = 0.55f
        return voice(
            d,
            { t -> 340f + 620f * exp(-t * 8f) },
            { t -> 1100f + 500f * exp(-t * 5f) },
            { _ -> 2200f },
            { t -> env(t, d, 0.012f, 0.28f) * (0.7f + 0.3f * sin(2f * PI.toFloat() * 22f * t)) },
            0.11f, 0.035f
        )
    }

    private fun earSqueak(): ShortArray {
        val d = 0.42f
        return voice(
            d,
            { t -> 720f + 300f * sin(2f * PI.toFloat() * t / d) },
            { _ -> 1250f },
            { _ -> 2500f },
            { t -> env(t, d, 0.015f, 0.16f) },
            0.025f, 0.05f
        )
    }

    private fun spin(): ShortArray {
        val d = 0.72f
        return voice(
            d,
            { t -> 280f + 520f * t / d },
            { t -> 650f + 450f * t / d },
            { t -> 1500f + 600f * t / d },
            { t -> env(t, d, 0.06f, 0.2f) * (0.65f + 0.35f * sin(2f * PI.toFloat() * 8f * t)) },
            0.055f, 0.02f
        )
    }

    private fun appleBite(): ShortArray {
        val d = 0.38f
        return voice(
            d,
            { t -> 760f - 180f * t / d },
            { _ -> 1550f },
            { _ -> 2900f },
            { t -> env(t, d, 0.008f, 0.16f) * (0.7f + 0.3f * sin(2f * PI.toFloat() * 19f * t)) },
            0.12f, 0.018f
        )
    }

    private fun fishMew(): ShortArray {
        val d = 0.68f
        return voice(
            d,
            { t -> 390f + 320f * sin(PI.toFloat() * t / d) },
            { t -> 650f + 380f * t / d },
            { _ -> 1950f },
            { t -> env(t, d, 0.07f, 0.24f) },
            0.035f, 0.04f
        )
    }

    private fun cookieCrunch(): ShortArray {
        val d = 0.46f
        return voice(
            d,
            { t -> 260f + 170f * sin(2f * PI.toFloat() * 3f * t) },
            { _ -> 820f },
            { _ -> 1500f },
            { t -> env(t, d, 0.01f, 0.19f) * (0.6f + 0.4f * sin(2f * PI.toFloat() * 13f * t)) },
            0.16f, 0.02f
        )
    }

    /**
     * Short, playful calls for the selectable animal friends. These are generated
     * locally so the app needs no downloaded audio files or network access.
     */
    private fun animalCall(kind: String, variant: String = "call"): ShortArray {
        val d = when (kind) {
            "elephant", "monkey", "dog", "parrot", "cow" -> 0.9f
            "bear", "tiger", "koala" -> 0.82f
            else -> 0.72f
        }
        val pi = PI.toFloat()
        fun pulse(t: Float, period: Float, on: Float): Float {
            val local = t % period
            return if (local < on) sin(pi * local / on) else 0f
        }
        val f0b: (Float) -> Float = { t ->
            when (kind) {
                "tiger" -> 180f + 115f * sin(pi * t / d) + 24f * sin(2f * pi * 7f * t)
                "elephant" -> 240f + 570f * sin(pi * t / d)
                "monkey" -> 330f + 170f * sin(2f * pi * 2.7f * t)
                "panda" -> 230f + 85f * sin(pi * t / d)
                "rabbit" -> 880f - 260f * t / d
                "cat" -> 390f + 300f * sin(pi * t / d)
                "dog" -> 250f + 90f * sin(2f * pi * 3f * t)
                "fox" -> 520f + 300f * sin(pi * t / d)
                "bear" -> 145f + 75f * sin(2f * pi * 2f * t)
                "pig" -> 190f + 110f * sin(2f * pi * 4f * t)
                "frog" -> 120f + 40f * sin(2f * pi * 12f * t)
                "penguin" -> 420f + 260f * sin(pi * t / d)
                "koala" -> 140f + 60f * sin(2f * pi * 3f * t)
                "cow" -> 135f + 55f * sin(pi * t / d)
                else -> 610f + 210f * sin(2f * pi * 2.4f * t)
            }
        }
        val form1b: (Float) -> Float = { t ->
            when (kind) {
                "elephant" -> 550f + 360f * sin(pi * t / d)
                "parrot" -> 900f + 550f * abs(sin(2f * pi * 2.4f * t))
                "rabbit", "fox" -> 1050f + 220f * sin(pi * t / d)
                "bear", "tiger", "koala" -> 460f + 210f * sin(pi * t / d)
                "cow" -> 520f + 130f * sin(pi * t / d)
                "frog" -> 520f
                "pig" -> 700f + 200f * sin(pi * t / d)
                "penguin" -> 950f + 300f * sin(pi * t / d)
                else -> 760f + 260f * sin(pi * t / d)
            }
        }
        val form2b: (Float) -> Float = { t ->
            when (kind) {
                "elephant" -> 1750f + 300f * sin(pi * t / d)
                "parrot" -> 2550f + 500f * sin(2f * pi * 2.4f * t)
                "rabbit", "fox" -> 2350f
                "bear", "tiger", "koala" -> 1350f
                "cow" -> 1150f
                "frog" -> 1500f
                else -> 1880f
            }
        }
        val rhy: (Float) -> Float = { t ->
            val r = when (kind) {
                "monkey" -> pulse(t, 0.22f, 0.14f)
                "dog" -> pulse(t, 0.27f, 0.17f)
                "parrot" -> pulse(t, 0.21f, 0.15f)
                "fox" -> if (t < 0.25f || t > 0.39f) 1f else 0.28f
                "tiger", "bear", "koala" -> 0.76f + 0.24f * sin(2f * pi * 18f * t)
                "frog" -> pulse(t, 0.3f, 0.2f)
                "pig" -> pulse(t, 0.24f, 0.16f)
                else -> 0.78f + 0.22f * sin(2f * pi * 8f * t)
            }
            r.coerceIn(0f, 1f)
        }
        val breathBase = when (kind) {
            "tiger", "bear", "elephant", "koala", "frog" -> 0.14f
            "parrot", "rabbit", "fox" -> 0.025f
            else -> 0.07f
        }
        val vibrato = if (kind == "rabbit" || kind == "parrot") 0.045f else 0.025f

        // base call: poori awaaz ka shape; variants isi ko chhota / tez / alag banate hain
        val dv = when (variant) {
            "ouch" -> 0.38f
            "giggle" -> 0.95f
            "biggiggle" -> 1.65f
            "squeak" -> 0.3f
            "sneeze" -> 0.62f
            "hello" -> d * 0.72f
            "chirp" -> 0.34f
            else -> d
        }
        val mid = d * 0.45f
        if (variant == "giggle" || variant == "biggiggle") {
            val maxIdx = if (variant == "biggiggle") 7 else 3
            fun idx(t: Float): Int = (t / 0.22f).toInt()
            fun loc(t: Float): Float = t - idx(t) * 0.22f
            return voice(
                dv,
                { t -> f0b(mid) * (1.05f + 0.05f * idx(t) + 0.14f * loc(t) / 0.15f) },
                { _ -> form1b(mid) },
                { _ -> form2b(mid) },
                { t -> if (idx(t) <= maxIdx && loc(t) < 0.15f) 0.9f * sin(pi * loc(t) / 0.15f) else 0f },
                breathBase, vibrato
            )
        }
        val scale = d / dv
        val pm: (Float) -> Float = { t ->
            when (variant) {
                "ouch" -> 1.55f - 0.65f * (t / dv)
                "squeak" -> 1.5f + 0.9f * (t / dv)
                "chirp" -> if (t < dv * 0.5f) 1.25f else 1.8f
                "sneeze" -> if (t < 0.28f) 1.2f else 0.7f + 1.1f * exp(-(t - 0.28f) * 5f)
                else -> 1f
            }
        }
        val amp: (Float) -> Float = { t ->
            when (variant) {
                "sneeze" -> when {
                    t < 0.18f -> 0.55f * (t / 0.18f)
                    t < 0.28f -> 0f
                    else -> exp(-(t - 0.28f) * 5f)
                }
                "chirp" -> {
                    val gap = if (t > dv * 0.46f && t < dv * 0.54f) 0f else 1f
                    env(t, dv, 0.01f, 0.12f) * gap
                }
                "ouch", "squeak" -> env(t, dv, 0.01f, dv * 0.5f) * rhy(t * scale).coerceAtLeast(0.7f)
                else -> env(t, dv, 0.02f, 0.22f) * rhy(t * scale)
            }
        }
        val breath = if (variant == "sneeze") 0.4f else breathBase
        return voice(
            dv,
            { t -> f0b(t * scale) * pm(t) },
            { t -> form1b(t * scale) },
            { t -> form2b(t * scale) },
            amp, breath, vibrato
        )
    }

    // ---------------- synth core ----------------

    private fun voice(
        dur: Float,
        f0: (Float) -> Float,
        f1: (Float) -> Float,
        f2: (Float) -> Float,
        amp: (Float) -> Float,
        breath: Float,
        vib: Float
    ): ShortArray {
        val n = (dur * sr).toInt()
        val out = ShortArray(n)
        val rnd = java.util.Random(7)
        val twoPi = 2.0 * PI
        val piF = PI.toFloat()
        var phase = 0.0
        for (i in 0 until n) {
            val t = i.toFloat() / sr
            val f = f0(t) * (1f + vib * sin(2f * piF * 5.5f * t))
            phase += f.toDouble() / sr
            val form1 = f1(t)
            val form2 = f2(t)
            var sum = 0f
            for (k in 1..18) {
                val fk = f * k
                if (fk > 6000f) break
                val d1 = (fk - form1) / (form1 * 0.35f + 80f)
                val d2 = (fk - form2) / (form2 * 0.30f + 100f)
                val g = exp(-d1 * d1) + 0.6f * exp(-d2 * d2) + 0.06f / k
                sum += g * sin(twoPi * k * phase).toFloat()
            }
            val noise = (rnd.nextFloat() * 2f - 1f) * breath
            val v = tanh(sum * 0.45f + noise) * amp(t)
            out[i] = (v * 30000f).toInt().toShort()
        }
        return out
    }

    private fun writeWav(f: File, pcm: ShortArray) {
        val dataLen = pcm.size * 2
        val bb = ByteBuffer.allocate(44 + dataLen).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray())
        bb.putInt(36 + dataLen)
        bb.put("WAVE".toByteArray())
        bb.put("fmt ".toByteArray())
        bb.putInt(16)
        bb.putShort(1.toShort())
        bb.putShort(1.toShort())
        bb.putInt(sr)
        bb.putInt(sr * 2)
        bb.putShort(2.toShort())
        bb.putShort(16.toShort())
        bb.put("data".toByteArray())
        bb.putInt(dataLen)
        for (v in pcm) bb.putShort(v)
        FileOutputStream(f).use { it.write(bb.array()) }
    }
}
